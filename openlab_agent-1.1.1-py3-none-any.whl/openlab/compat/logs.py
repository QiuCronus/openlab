import functools
import logging
import time

__all__ = ["log", "handle_stdout", "LogLevel", "log_record"]

log = logging.getLogger("application")
log.setLevel(logging.DEBUG)

_DFT_FMT = "[%(levelname).1s] %(asctime)s: %(message)s"
_DFT_FMT_TIME = "%Y/%m/%d %H:%M:%S"


class LogLevel:
    DEBUG = logging.DEBUG
    INFO = logging.INFO
    WARN = logging.WARN
    ERROR = logging.ERROR

    _MAPS = {"debug": DEBUG, "info": INFO, "warning": WARN, "error": ERROR}

    @staticmethod
    def gets(level: str):
        if level in LogLevel._MAPS.keys():
            return LogLevel._MAPS[level]
        return LogLevel.DEBUG


def log_record(func):
    @functools.wraps(func)
    def wrapper(self, *args, **kwargs):
        class_name = self.__class__.__name__
        func_name = func.__name__
        # log.debug(f"[Monitor] {class_name}::{func_name}(): args={args}")
        # log.debug(f"[Monitor] {class_name}::{func_name}(): kwargs={kwargs}")
        _start = time.time() * 1000
        _reply = func(self, *args, **kwargs)
        _spend = time.time() * 1000 - _start
        log.debug(f"[Monitor] {class_name}::{func_name}(): {_spend}ms.")
        return _reply

    return wrapper


def handle_stdout(level=None):
    if level is None:
        level = LogLevel.INFO
    console = logging.StreamHandler()
    console.setFormatter(logging.Formatter(_DFT_FMT, _DFT_FMT_TIME))
    console.setLevel(level)
    log.addHandler(console)
