from .utils import DataUtils

__all__ = [
    "GlobalOption",
    "DriverOption",
    "BrokerOption",
]


class GlobalOption:
    def __init__(self):
        self.support_category = None
        self.support_domains = []

    @staticmethod
    def load(data: dict):
        opt = GlobalOption()
        opt.support_category = int(DataUtils.get_values(data, "CATEGORY", 0))
        opt.support_domains = DataUtils.get_values(data, "DOMAIN", [])
        return opt


class DriverOption:
    def __init__(self) -> None:
        self.host = "localhost"
        self.port = 0
        self.user = None
        self.password = None
        self.database = None

    def __str__(self) -> str:
        return (
            f"<DriverOption "
            f"host={self.host}, "
            f"port={self.port}, "
            f"user={self.user}, "
            f"db={self.database}>."
        )

    @staticmethod
    def load(data: dict):
        opt = DriverOption()
        opt.host = str(DataUtils.get_values(data, "HOST"))
        opt.port = int(DataUtils.get_values(data, "PORT"))
        opt.user = str(DataUtils.get_values(data, "USER"))
        opt.password = str(DataUtils.get_values(data, "PASSWD"))
        opt.database = DataUtils.get_values(data, "DBNAME")
        return opt


class BrokerOption:
    def __init__(self):
        self.host = None
        self.port = 0
        self.user = None
        self.password = None
        self.virtual_host = None
        self.exchange = None
        self.queue = None
        self.route = None
        self.max_queue_length = 1024

    def __str__(self) -> str:
        return (
            f"<BrokerOption "
            f"host={self.host}, "
            f"port={self.port}, "
            f"virtual_host={self.virtual_host}, "
            f"user={self.user}, "
            f"exchange={self.exchange}, "
            f"queue={self.queue}, "
            f"route={self.route}>."
        )

    @staticmethod
    def load(data: dict):
        opt = BrokerOption()
        opt.host = str(DataUtils.get_values(data, "HOST"))
        opt.port = int(DataUtils.get_values(data, "PORT"))
        opt.user = str(DataUtils.get_values(data, "USER"))
        opt.password = str(DataUtils.get_values(data, "PASSWD"))
        opt.virtual_host = DataUtils.get_values(data, "VHOST")
        opt.exchange = DataUtils.get_values(data, "EXCHANGE")
        opt.queue = DataUtils.get_values(data, "QUEUE")
        opt.route = DataUtils.get_values(data, "ROUTE")
        opt.max_queue_length = DataUtils.get_values(data, "MAX_QUEUE_LENGTH") or 1024
        return opt
