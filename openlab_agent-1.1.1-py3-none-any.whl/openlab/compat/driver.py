import enum
from abc import abstractmethod

import pymysql
from pymysql.cursors import DictCursor

from .errors import DriverError
from .logs import log, log_record
from .options import DriverOption


class Command(enum.IntEnum):
    TASK = 1
    CANCEL = 2
    RECYCLE = 10
    PAUSE = 11


class TaskStatus(enum.IntEnum):
    PENDING = 0
    DEALING = 1
    SUCCESS = 2
    FAILED = 3
    FINISHED = 4
    CANCELLED = 5
    CANCELLING = 15
    RECYCLING = 16
    PAUSING = 17
    PAUSED = 18


class IDriver:
    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.disconnect()
        return False

    @abstractmethod
    def connect(self):
        raise NotImplementedError

    @abstractmethod
    def disconnect(self):
        raise NotImplementedError

    @abstractmethod
    def is_connected(self) -> bool:
        raise NotImplementedError


class IMySQLDriver(IDriver):
    def __init__(self, option: DriverOption) -> None:
        super().__init__()
        self.option = option
        self.connection = None

    def connect(self):
        log.debug(f"{self.option}")
        params = dict(
            host=self.option.host,
            port=self.option.port,
            user=self.option.user,
            password=self.option.password,
            cursorclass=DictCursor,
            autocommit=True,
        )
        if self.option.database:
            params.update({"database": self.option.database})
        self.connection = pymysql.connect(**params)

    def disconnect(self):
        if self.connection:
            self.connection.close()

    def is_connected(self) -> bool:
        try:
            self.connection.ping(reconnect=True)
            return True
        except Exception as err:
            log.error(err)
            return False

    @log_record
    def query(self, sql: str):
        log.debug(f"[Driver] sql:{sql}")
        if not self.is_connected():
            raise DriverError("driver connection disconnected.")
        with self.connection.cursor() as cursor:
            try:
                cursor.execute(sql)
                return cursor.fetchone()
            except pymysql.err.ProgrammingError as err:
                log.error(err)
                return None

    @log_record
    def querys(self, sql: str, params: list = None):
        log.debug(f"[Driver] sql:{sql}")
        if not self.is_connected():
            raise DriverError("driver connection disconnected.")
        with self.connection.cursor() as cursor:
            try:
                if params:
                    cursor.executemany(sql, params)
                else:
                    cursor.execute(sql)
                rows = [row for row in cursor.fetchall()]
                return rows
            except pymysql.err.ProgrammingError as err:
                log.error(err)
                return []

    @log_record
    def update(self, sql: str):
        log.debug(f"[Driver] sql:{sql}")
        if not self.is_connected():
            raise DriverError("driver connection disconnected.")
        with self.connection.cursor() as cursor:
            try:
                effected = cursor.execute(sql)
                return effected
            except pymysql.err.ProgrammingError as err:
                log.error(err)
                return -1

    @log_record
    def updatemany(self, sql: str, params: list):
        log.debug(f"[Driver] sql:{sql}")
        if not self.is_connected():
            raise DriverError("driver connection disconnected.")
        with self.connection.cursor() as cursor:
            try:
                effected = cursor.executemany(sql, params)
                return effected
            except pymysql.err.ProgrammingError as err:
                log.error(err)
                return -1
