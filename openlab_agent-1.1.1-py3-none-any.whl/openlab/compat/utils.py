import base64
import bisect
import copy
import ctypes
import datetime
import hashlib
import importlib
import math
import os
import queue
import shutil
import signal
import socket
import sys
import tarfile
import typing
import uuid
import zlib

from .errors import ConfigError
from .logs import log

_4MB = 1 << 22

__all__ = [
    "make_fork",
    "load_clazz",
    "SignalReceiver",
    "CryptoUtils",
    "TimeUtils",
    "ConfigUtils",
    "CacheQueue",
    "DataUtils",
]


def load_clazz(path: str):
    try:
        dot = path.rindex(".")
    except ValueError:
        raise ValueError(f"Error loading object '{path}'")

    module, name = path[:dot], path[dot + 1 :]
    _package = importlib.import_module(module)
    try:
        _clazz = getattr(_package, name)
    except AttributeError:
        raise NameError(f"Module '{module}' doesn't define any class named '{name}'.")
    return _clazz


def make_fork() -> None:
    """Turn on daemon forking, run as a foreground process."""
    if sys.platform.lower() == "win32":
        return

    pid = os.fork()
    if pid > 0:
        sys.exit(0)

    os.setsid()
    os.umask(os.umask(0o077 | 0o022))
    fd = os.open(os.devnull, os.O_RDWR)
    os.dup2(fd, 0)
    os.dup2(fd, 1)
    os.dup2(fd, 2)


class SignalReceiver:

    signames: dict = {}

    def __init__(self) -> None:
        self._recvd = []
        for k, v in signal.__dict__.items():
            started = getattr(k, "startswith", None)
            if started is None:
                continue
            if started("SIG") and not started("SIG_"):
                self.signames[v] = k

    def register(self) -> None:
        signal.signal(signal.SIGINT, self.receive)
        signal.signal(signal.SIGTERM, self.receive)
        try:
            signal.signal(signal.SIGHUP, self.receive)
            signal.signal(signal.SIGUSR1, self.receive)
            signal.signal(signal.SIGQUIT, self.receive)
        except Exception as err:
            log.error(err, exc_info=False)

    def receive(self, signum, frame) -> None:
        if signum not in self._recvd:
            self._recvd.append(signum)

    def get_signals(self) -> typing.Optional[int]:
        if self._recvd:
            return self._recvd.pop(0)
        return None

    def get_names(self, signum):
        return self.signames.get(signum) or f"signal-{signum}"


class CryptoUtils:
    _LIB = None

    @staticmethod
    def _load() -> None:
        if CryptoUtils._LIB:
            return
        suffix = "dll" if sys.platform.lower().startswith("win") else "so"
        lib = os.path.join(os.path.dirname(__file__), f"crypto.{suffix}")
        CryptoUtils._LIB = ctypes.CDLL(lib)
        CryptoUtils._LIB.init()

    @staticmethod
    def _encrypt_string(data: str, encoding: str = "UTF-8") -> typing.Optional[str]:
        raw_data = data.encode(encoding)
        raw_length = len(raw_data)
        raw_output = ctypes.create_string_buffer(int(raw_length * 2 + 1))
        ret = CryptoUtils._LIB.doEncryptString(raw_data, raw_length, raw_output)
        if ret == 0:
            return raw_output.value.decode(encoding)
        return None

    @staticmethod
    def _decrypt_string(data: str, encoding: str = "UTF-8") -> typing.Optional[str]:
        raw_data = data.encode(encoding)
        raw_length = len(raw_data)
        raw_output = ctypes.create_string_buffer(int(raw_length / 2))
        ret = CryptoUtils._LIB.doDecryptString(raw_data, raw_length, raw_output)
        if ret == 0:
            return raw_output.value.decode(encoding)
        return None

    @staticmethod
    def _encrypt_bytes(data: bytes) -> typing.Optional[bytes]:
        raw_data = copy.copy(data)
        raw_length = len(raw_data)
        ret = CryptoUtils._LIB.doEncryptBytes(raw_data, raw_length)
        if ret == 0:
            return raw_data
        return None

    @staticmethod
    def _decrypt_bytes(data: bytes) -> typing.Optional[bytes]:
        raw_data = copy.copy(data)
        raw_length = len(raw_data)
        ret = CryptoUtils._LIB.doEncryptBytes(raw_data, raw_length)
        if ret == 0:
            return raw_data
        return None

    @staticmethod
    def encrypt(data: typing.Union[str, bytes]) -> typing.Union[None, str, bytes]:
        CryptoUtils._load()
        if isinstance(data, str):
            return CryptoUtils._encrypt_string(data)
        elif isinstance(data, bytes):
            return CryptoUtils._encrypt_bytes(data)
        return None

    @staticmethod
    def decrypt(data: typing.Union[str, bytes]) -> typing.Union[None, str, bytes]:
        CryptoUtils._load()
        if isinstance(data, str):
            return CryptoUtils._decrypt_string(data)
        elif isinstance(data, bytes):
            return CryptoUtils._decrypt_bytes(data)
        return None


class TimeUtils:
    timedelta: datetime.timedelta = datetime.timedelta

    @staticmethod
    def datetime() -> datetime.datetime:
        utc = datetime.datetime.utcnow()
        offset = datetime.timedelta(hours=8)
        return utc + offset

    @staticmethod
    def strtime(fmt: str = "%Y-%m-%d %H:%M:%S") -> str:
        now = TimeUtils.datetime()
        return now.strftime(fmt)

    @staticmethod
    def timestamp(length: int = 10) -> int:
        bit = length - 10 if length > 10 else 0
        _t = math.pow(10, bit)
        now = TimeUtils.datetime()
        timestamp = now.timestamp()
        return int(timestamp * _t)

    @staticmethod
    def get_date(delta, return_str: bool = False, fmt: str = "%Y-%m-%d %H:%M:%S"):
        now = TimeUtils.datetime()
        target = now + delta
        if return_str:
            return target.strftime(fmt)
        return target


class ConfigUtils:
    @staticmethod
    def load_config(filepath: str) -> dict:
        filename = os.path.basename(filepath)
        suffix = os.path.splitext(filename)[1]
        suffix = suffix.lower()

        log.debug(f"<Config name={filename}, suffix={suffix}>. ")
        if suffix == ".json":
            return ConfigUtils.load_json(filepath)

        elif suffix in (".yml", ".yaml"):
            return ConfigUtils.load_yaml(filepath)

        elif suffix == ".ini":
            return ConfigUtils.load_ini(filepath)

        else:
            raise ConfigError(
                f"Config file extension: '{suffix}' not supported at present."
            )

    @staticmethod
    def _process_session(mappings: dict) -> dict:
        for session, values in mappings.items():
            if session in ("GLOBAL", "DEFAULT"):
                continue
            is_encrypted = values.get("ENC", True)
            if is_encrypted:
                for key, value in values.items():
                    mappings[session][key] = CryptoUtils.decrypt(value)
        return mappings

    @staticmethod
    def load_json(filepath: str) -> dict:
        log.debug(f"loading json config file...")

        try:
            import ujson as json

            log.debug(f"using thrid-package: ujson(version={json.__version__})")
        except ImportError:
            import json

        with open(filepath, "r") as fd:
            mappings = json.load(fd)

        return ConfigUtils._process_session(mappings)

    @staticmethod
    def load_yaml(filepath: str) -> dict:
        log.debug(f"loading yaml config file...")
        try:
            import yaml

            log.debug(f"using third-package: PyYAML(version={yaml.__version__})")
        except ImportError:
            raise ConfigError(f"Missing yaml lib, use `pip install pyyaml` to install.")
        else:
            with open(filepath, "r") as fd:
                mappings = yaml.load(fd, Loader=yaml.FullLoader)

            return ConfigUtils._process_session(mappings)

    @staticmethod
    def load_ini(filepath: str) -> dict:
        log.debug(f"loading ini config file...")

        import configparser

        parser = configparser.SafeConfigParser()
        if not parser.read(filepath):
            raise ConfigError(f"read config file failed.")

        mappings = {}
        for section in parser.sections():
            for option in parser.options(section):
                mappings[section] = {option: parser.get(section, option)}

        return ConfigUtils._process_session(mappings)


class CacheQueue:
    def __init__(self, max_length: int = 4096) -> None:
        self._caches = queue.Queue(maxsize=max_length)

    def size(self) -> int:
        return self._caches.qsize()

    def put(self, data: typing.Any) -> bool:
        try:
            self._caches.put_nowait(data)
            return True
        except queue.Full:
            return False

    def get_data(self) -> typing.Optional[typing.Any]:
        try:
            return self._caches.get_nowait()
        except queue.Empty:
            return None


class DataUtils:
    @staticmethod
    def get_values(data: dict, key: str, default=None):
        if data and isinstance(data, dict):
            if key in data.keys():
                return data.get(key)
        return default

    @staticmethod
    def scan_dirs(
        dirpath: str,
        limit_scan_size: int = 0,
        limit_file_size: int = 0,
        exclude_suffix: list = None,
    ) -> list:
        if exclude_suffix is None:
            exclude_suffix = [".tmp", ".temp", ".TMP", ".TEMP"]
        paths = set()
        for root, _, names in os.walk(dirpath):
            for name in names:
                fpath = os.path.join(root, name)
                fsize = os.path.getsize(fpath)
                _, suffix = os.path.splitext(name)
                if exclude_suffix and suffix in exclude_suffix:
                    continue
                if 0 < limit_file_size < fsize:
                    continue
                if 0 < limit_scan_size < len(paths):
                    return list(paths)
                paths.add(fpath)
        return list(paths)

    @staticmethod
    def mkdir(path: str) -> str:
        if not os.path.exists(path):
            os.makedirs(path)
        return path

    @staticmethod
    def read_file(filepath: str, mode: str = "rb") -> typing.Union[None, str, bytes]:
        with open(filepath, mode) as fd:
            return fd.read()

    @staticmethod
    def write_file(filepath: str, raw: typing.Union[str, bytes]) -> None:
        dirpath, filename = os.path.split(filepath)
        DataUtils.mkdir(dirpath)
        mode = "wb" if isinstance(raw, bytes) else "w"
        with open(filepath, mode) as fd:
            fd.write(raw)

    @staticmethod
    def join_path(*args) -> str:
        return os.path.join(*args)

    @staticmethod
    def rmdir(dirpath: str) -> None:
        shutil.rmtree(dirpath, ignore_errors=True)

    @staticmethod
    def hostname() -> typing.Optional[str]:
        return socket.gethostname()

    @staticmethod
    def disk_free_space(root: str = "/") -> int:
        total, used, free = shutil.disk_usage(root)
        return free

    @staticmethod
    def format_size(size: int) -> str:
        d = [
            (1024 - 1, "KB"),
            (1024 ** 2 - 1, "MB"),
            (1024 ** 3 - 1, "GB"),
            (1024 ** 4 - 1, "TB"),
        ]
        s = [x[0] for x in d]
        index = bisect.bisect_left(s, size) - 1
        if index == -1:
            return str(size) + "B"
        b, u = d[index]
        return str(size / (b + 1)) + u

    @staticmethod
    def str_to_bytes(data: str, encoding: str = "UTF-8") -> typing.Optional[bytes]:
        if data and isinstance(data, str):
            return data.encode(encoding)
        return None

    @staticmethod
    def bytes_to_str(data: bytes, encoding: str = "UTF-8") -> typing.Optional[str]:
        if data and isinstance(data, bytes):
            return data.decode(encoding)
        return None

    @staticmethod
    def b64encode(
        data: typing.Union[str, bytes], return_str: bool = True, encoding: str = "UTF-8"
    ) -> typing.Union[None, str, bytes]:

        if data and isinstance(data, str):
            raw = DataUtils.str_to_bytes(data, encoding)
        else:
            raw = data
        _raw = base64.b64encode(raw)
        if return_str:
            return _raw.decode(encoding)
        return _raw

    @staticmethod
    def b64decode(
        data: typing.Union[str, bytes], return_str: bool = True, encoding: str = "UTF-8"
    ) -> typing.Union[None, str, bytes]:

        if isinstance(data, str):
            raw = DataUtils.str_to_bytes(data, encoding)
        else:
            raw = data
        _raw = base64.b64decode(raw)
        if return_str:
            return _raw.decode(encoding)
        return _raw

    @staticmethod
    def MD5(data: typing.Union[str, bytes]) -> str:
        if isinstance(data, str):
            raw = DataUtils.str_to_bytes(data)
        else:
            raw = data

        m = hashlib.md5()
        m.update(raw)
        return m.hexdigest()

    @staticmethod
    def MD5_bigfile(filepath: str) -> str:
        m = hashlib.md5()
        chunk_size = 8192
        with open(filepath, "rb") as fd:
            while True:
                chunk = fd.read(chunk_size)
                if not chunk:
                    break
                m.update(chunk)
        return m.hexdigest()

    @staticmethod
    def UUID() -> str:
        return uuid.uuid4().hex

    @staticmethod
    def ZIP(data: typing.Union[str, bytes], encoding: str = "UTF-8") -> bytes:
        if isinstance(data, str):
            raw = data.encode(encoding)
        else:
            raw = data
        return zlib.compress(raw)

    @staticmethod
    def UNZIP(data: typing.Union[str, bytes], encoding: str = "UTF-8") -> bytes:
        if isinstance(data, str):
            raw = data.encode(encoding)
        else:
            raw = data
        return zlib.decompress(raw)

    @staticmethod
    def targz(filepaths: list, targz_path: str) -> None:
        with tarfile.open(targz_path, "w:gz") as fd:
            for fpath in filepaths:
                dpath = os.path.basename(fpath)
                fd.add(fpath, arcname=dpath)

    @staticmethod
    def un_targz(targz_path: str, store_path: str) -> None:
        fd = tarfile.open(targz_path)
        fd.extractall(path=store_path)
