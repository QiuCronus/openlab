import os

from .driver import IMySQLDriver, Command, TaskStatus
from .errors import ConfigError, DriverError, BrokerError
from .logs import log, handle_stdout, LogLevel, log_record
from .model import IProgram
from .options import DriverOption, BrokerOption, GlobalOption
from .utils import (
    ConfigUtils,
    DataUtils,
    SignalReceiver,
    TimeUtils,
    CryptoUtils,
    make_fork,
)

DIR_DATA = DataUtils.join_path(os.getcwd(), "Data")
#
DIR_ERROR = DataUtils.join_path(DIR_DATA, "Error")
DIR_ERR_PARSE_TASK = DataUtils.join_path(DIR_ERROR, "Task")
DIR_ERR_SEND = DataUtils.join_path(DIR_ERROR, "Send")
DIR_ERR_SEND_HEARTBEAT = DataUtils.join_path(DIR_ERR_SEND, "Heartbeat")
DIR_ERR_SEND_SITUATION = DataUtils.join_path(DIR_ERR_SEND, "Situation")
DIR_ERR_SEND_TASK = DataUtils.join_path(DIR_ERR_SEND, "Task")
DIR_ERR_SEND_UNKNOWN = DataUtils.join_path(DIR_ERR_SEND, "Unknown")
DIR_ERR_RECV = DataUtils.join_path(DIR_ERROR, "Recv")
DIR_ERR_RECV_HEARTBEAT = DataUtils.join_path(DIR_ERR_RECV, "Heartbeat")
DIR_ERR_RECV_SITUATION = DataUtils.join_path(DIR_ERR_RECV, "Situation")
DIR_ERR_RECV_TASK = DataUtils.join_path(DIR_ERR_RECV, "Task")
DIR_ERR_RECV_UNKNOWN = DataUtils.join_path(DIR_ERR_RECV, "Unknown")
#
DIR_SEND = DataUtils.join_path(DIR_DATA, "Send")
DIR_SEND_HEARTBEAT = DataUtils.join_path(DIR_SEND, "Heartbeat")
DIR_SEND_SITUATION = DataUtils.join_path(DIR_SEND, "Situation")
DIR_SEND_TASK = DataUtils.join_path(DIR_SEND, "Task")
DIR_SEND_UNKNOWN = DataUtils.join_path(DIR_SEND, "Unknown")
##
DIR_RECV = DataUtils.join_path(DIR_DATA, "Recv")
DIR_RECV_HEARTBEAT = DataUtils.join_path(DIR_RECV, "Heartbeat")
DIR_RECV_SITUATION = DataUtils.join_path(DIR_RECV, "Situation")
DIR_RECV_TASK = DataUtils.join_path(DIR_RECV, "Task")
DIR_RECV_UNKNOWN = DataUtils.join_path(DIR_RECV, "Unknown")

for path in (
    DIR_DATA,
    DIR_ERROR,
    DIR_SEND,
    DIR_RECV,
    DIR_ERR_SEND,
    DIR_ERR_PARSE_TASK,
    DIR_ERR_SEND_HEARTBEAT,
    DIR_ERR_SEND_SITUATION,
    DIR_ERR_SEND_TASK,
    DIR_ERR_SEND_UNKNOWN,
    DIR_ERR_RECV,
    DIR_ERR_RECV_HEARTBEAT,
    DIR_ERR_RECV_SITUATION,
    DIR_ERR_RECV_TASK,
    DIR_ERR_RECV_UNKNOWN,
    DIR_SEND_HEARTBEAT,
    DIR_SEND_SITUATION,
    DIR_SEND_TASK,
    DIR_SEND_UNKNOWN,
    DIR_RECV_HEARTBEAT,
    DIR_RECV_SITUATION,
    DIR_RECV_TASK,
    DIR_RECV_UNKNOWN,
):
    DataUtils.mkdir(path)
