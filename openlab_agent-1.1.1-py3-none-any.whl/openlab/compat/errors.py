class DriverError(Exception):
    pass


class ConfigError(Exception):
    pass


class TimeoutError(Exception):
    pass


class BrokerError(Exception):
    pass
