import abc
import signal
import time
import threading

from .logs import log
from .utils import DataUtils, SignalReceiver, TimeUtils
from .errors import ConfigError


class IWorker(threading.Thread):
    def __init__(self):
        self._interrupted = False
        self._age = TimeUtils.timestamp()
        super(IWorker, self).__init__()

    def shutdown(self):
        self._interrupted = True

    @property
    def age(self):
        return self._age

    @property
    def interrupted(self) -> bool:
        return self._interrupted

    def run(self) -> None:
        try:
            self.on_started()
            if not self.interrupted:
                self.working()
        finally:
            self.on_destroy()

    @abc.abstractmethod
    def on_started(self):
        raise NotImplementedError

    @abc.abstractmethod
    def working(self):
        raise NotImplementedError

    @abc.abstractmethod
    def on_destroy(self):
        raise NotImplementedError


class IProgram:
    def __init__(self):
        self.interrupted = False
        self.restart = False
        self.signal_receiver = SignalReceiver()
        self.signal_receiver.register()
        self.machine_id = DataUtils.hostname()

    def handle_signals(self):
        signum = self.signal_receiver.get_signals()
        if signum is None:
            return

        if signum in (signal.SIGINT, signal.SIGTERM):
            self.interrupted = True
            return

        sigquit = getattr(signal, "SIGQUIT")
        if sigquit and signum == sigquit:
            self.interrupted = True
            return

        sighup = getattr(signal, "SIGHUP")
        if sighup and signum == sighup:
            self.restart = True
            return

    def run_forever(self):
        started, interval = 0, 60
        while not self.interrupted:
            try:
                time.sleep(0.5)
            except KeyboardInterrupt:
                break
            self.handle_signals()
            if TimeUtils.timestamp() - started > interval:
                try:
                    self.working()
                except ConfigError as err:
                    log.exception(err)
                    break
                except Exception as err:
                    log.exception(err)
                finally:
                    started = TimeUtils.timestamp()
        self.stop()

    @abc.abstractmethod
    def load_config(self):
        raise NotImplementedError

    @abc.abstractmethod
    def working(self):
        raise NotImplementedError

    @abc.abstractmethod
    def stop(self):
        raise NotImplementedError
