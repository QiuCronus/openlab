import click


@click.group(context_settings={"help_option_names": ["-h", "--help"]})
def cli():
    """"""


@cli.command(name="heartbeat")
@click.option("-m", "--module", required=True, type=click.STRING, help="module name")
@click.option(
    "-f", "--config", required=True, type=click.STRING, help="config file path"
)
@click.option("--vhost", type=click.STRING, default=None, help="virtual host")
@click.option("--dbname", type=click.STRING, default=None)
@click.option(
    "-l",
    "--level",
    type=click.Choice(["debug", "info", "warning", "error"]),
    default="info",
)
def heartbeat(module, config, vhost, dbname, level):
    from .heartbeat import run_forever

    run_forever(module, config, vhost, dbname, level)


@cli.command(name="situation")
@click.option("-m", "--module", type=click.STRING)
@click.option("-f", "--config", type=click.STRING, help="config file path")
@click.option("--vhost", type=click.STRING, default=None, help="virtual host")
@click.option("--dbname", type=click.STRING, default=None)
@click.option(
    "-l",
    "--level",
    type=click.Choice(["debug", "info", "warning", "error"]),
    default="info",
)
def situation(module, config, vhost, dbname, level):
    from .situation import run_forever

    run_forever(module, config, vhost, dbname, level)


@cli.command(name="task")
@click.option("-f", "--config", type=click.STRING, help="config file path")
@click.option("--vhost", type=click.STRING, default=None, help="virtual host")
@click.option(
    "-l",
    "--level",
    type=click.Choice(["debug", "info", "warning", "error"]),
    default="info",
)
def rpc_task(config, vhost, level):
    from .task import run_forever

    run_forever(config, vhost, level)
