import time
from typing import List, Dict

import pika
import pika.exceptions

from openlab.compat import BrokerOption, DriverOption
from openlab.compat import DataUtils, TimeUtils, ConfigUtils, CryptoUtils
from openlab.compat import DriverError, BrokerError
from openlab.compat import IMySQLDriver, Command, TaskStatus
from openlab.compat import IProgram
from openlab.compat import log, LogLevel, handle_stdout
from openlab.proto import message_pb2

EXCHANGE = "Task"
QUEUE = "Task_{machine_id}"
ROUTE = "task.{machine_id}"


class MySQLDriver(IMySQLDriver):
    def update_task_status(
        self, dbname: str, batch_id, task_id, category, domain, status
    ):
        try:
            sql = (
                f"UPDATE {dbname}.im_task "
                f"SET task_status = {status} "
                "WHERE command = 1 AND "
                f"batch_id = '{batch_id}' AND "
                f"task_id = '{task_id}' AND "
                f"category = {category} AND "
                f"domain = {domain};"
            )
            return self.update(sql)
        except Exception as err:
            raise DriverError(err)

    def query_task_status(self, dbname: str, batch_id, task_id, category, domain):
        try:
            sql = (
                "SELECT task_status AS status "
                f"FROM {dbname}.im_task WHERE "
                f"batch_id = '{batch_id}' AND "
                f"task_id = '{task_id}' AND "
                f"category = {category} AND "
                f"domain = {domain};"
            )
            rows = self.query(sql)
            if rows:
                return DataUtils.get_values(rows, "status", -1)
            return -1
        except Exception as err:
            raise DriverError(err)

    def delete_task_record(self, dbname: str, batch_id, task_id, category, domain):
        try:
            sql = (
                f"DELETE FROM {dbname}.im_task WHERE "
                f"batch_id = '{batch_id}' AND "
                f"task_id = '{task_id}' AND "
                f"category = {category} AND "
                f"domain = {domain};"
            )
            return self.update(sql)
        except Exception as err:
            raise DriverError(err)

    def add_tasks(self, dbname: str, tasks: List[Dict]):
        try:
            sql = (
                f"INSERT INTO {dbname}.im_task ("
                f"`batch_id`, `task_id`, `target`, `category`, `domain`, `param1`, `param2`,"
                f"`task_status`, `update_time`, `is_auto_join`, `task_priority`, `command`,"
                f"`is_gathered`, `server_ip`, `is_deleted`, `use_count`, `is_dispatched`,"
                f"`gather_time`) "
                f"VALUES ("
                f"%(batch_id)s,%(task_id)s,%(target)s,%(category)s,%(domain)s,%(param1)s,%(param2)s,%(task_status)s,"
                f"%(update_time)s,%(is_auto_join)s,%(task_priority)s,%(command)s,%(is_gathered)s,%(server_ip)s,"
                f"%(is_deleted)s,%(use_count)s,"
                f"%(is_dispatched)s, %(gather_time)s);"
            )
            return self.updatemany(sql, tasks)
        except Exception as err:
            raise DriverError(err)


class TaskMixin:
    def recipe_task(self, driver: MySQLDriver, channel, queue):
        frame = channel.queue_declare(queue=queue, durable=True)
        if frame and frame.method.message_count == 0:
            return

        for _ in range(frame.method.message_count):
            try:
                method, props, body = channel.basic_get(queue)
                if not method or not props:
                    continue

                self.handle_packet(driver, body)
                channel.basic_ack(method.delivery_tag)

                if method.message_count == 0:
                    return

            except pika.exceptions.AMQPError as err:
                raise BrokerError(err)
            except Exception as err:
                log.exception(err)
                return

    def handle_packet(self, driver: MySQLDriver, body: bytes):
        packet = message_pb2.Packet()
        if packet.ParseFromString(body) <= 0:
            raise RuntimeError("[Protobuf] marshal packet failed.")

        if packet.msg_type not in (
            message_pb2.MSGTYPE.command,
            message_pb2.MSGTYPE.task,
        ):
            errmsg = (
                f"[Protobuf] Not Allow MsgType: {packet.msg_type},"
                f"expect {message_pb2.MSGTYPE.command} or "
                f"{message_pb2.MSGTYPE.task}"
            )
            raise RuntimeError(errmsg)

        if packet.filehash != DataUtils.MD5(packet.raw):
            raise RuntimeError("[Task] packet maybe modified!!!")

        log.info(
            f"<Packet ts={packet.timestamp}, label={packet.label}, "
            f"filename={packet.filename}>."
        )

        raw_encrypt = DataUtils.UNZIP(packet.raw)
        if not raw_encrypt:
            raise RuntimeError("UNZIP task failed.")
        raw = CryptoUtils.decrypt(raw_encrypt)
        if not raw:
            raise RuntimeError("Decrypt task failed.")

        batch = message_pb2.Batch()
        if batch.ParseFromString(raw) <= 0:
            raise RuntimeError("[Protobuf] marshal batch failed.")
        #
        self.handle_batchs(driver, batch)

    def handle_batchs(self, driver: MySQLDriver, batch: message_pb2.Batch):
        for task in batch.tasks:
            if task.command == Command.TASK:
                self.add_task(driver, batch.dbname, task)
            elif task.command in (Command.CANCEL, Command.PAUSE):
                self.do_command(driver, batch.dbname, task)
            else:
                log.warning(f"No support command={task.command}. Just Ignore.")

    def add_task(self, driver: MySQLDriver, dbname: str, task: message_pb2.Task):
        _status = driver.query_task_status(
            dbname=dbname,
            batch_id=task.batch_id,
            task_id=task.task_id,
            category=task.category,
            domain=task.domain,
        )
        if _status >= 0:
            # record already exists !!
            if _status in (TaskStatus.PENDING, TaskStatus.RECYCLING):
                log.debug(
                    f"<Task batch_id={task.batch_id}, task_id={task.task_id},"
                    f"category={task.category}, domain={task.domain}>."
                )
                log.info(
                    f"Ignore <Task batch_id={task.batch_id}, task_id={task.task_id}>."
                )
                return

            log.info(
                f"try to delete <Task batch_id={task.batch_id}, task_id={task.task_id}>."
            )
            deleted_count = driver.delete_task_record(
                dbname=dbname,
                batch_id=task.batch_id,
                task_id=task.task_id,
                category=task.category,
                domain=task.domain,
            )
            log.debug(f"deleted_count: {deleted_count}")
        t = {
            "batch_id": task.batch_id,
            "task_id": task.task_id,
            "target": task.target,
            "category": task.category,
            "domain": task.domain,
            "param1": task.param1,
            "param2": task.param2,
            "task_priority": task.task_priority,
            "remark": task.remark,
            "command": task.command,
            "task_status": 0,
            "update_time": TimeUtils.strtime(),
            "is_gathered": 0,
            "gather_time": TimeUtils.timestamp(),
            "server_ip": DataUtils.hostname(),
            "is_auto_join": 1,
            "is_deleted": 0,
            "use_count": 0,
            "is_dispatched": 1,
        }
        inserted_count = driver.add_tasks(dbname, [t])
        if inserted_count != 1:
            raise RuntimeError(f"inserted task failed. inserted_count={inserted_count}")

    def do_command(self, driver: MySQLDriver, dbname: str, task: message_pb2.Task):
        effected = driver.update_task_status(
            dbname=dbname,
            batch_id=task.batch_id,
            task_id=task.task_id,
            category=task.category,
            domain=task.domain,
            status=task.status,
        )
        log.info(
            f"<Command batch_id={task.batch_id}, task_id={task.task_id}, "
            f"category={task.category}, domain={task.domain}> --> "
            f"{task.status}, effected={effected}."
        )


class Program(IProgram, TaskMixin):
    def __init__(self, *args, **kwargs):
        super(Program, self).__init__()
        self.cfgpath = kwargs["config"]
        self.vhost = kwargs["vhost"]
        #
        self.configs = {}
        self.broker_option = None
        self.driver_option = None
        self.load_config()

    def load_config(self):
        self.configs.clear()
        self.configs = ConfigUtils.load_config(self.cfgpath)
        #
        driver = DataUtils.get_values(self.configs, "DRIVER")
        self.driver_option = DriverOption.load(driver)
        broker = DataUtils.get_values(self.configs, "BROKER")
        self.broker_option = BrokerOption.load(broker)
        if self.vhost:
            self.broker_option.virtual_host = self.vhost

    def working(self):
        if self.restart:
            self.load_config()
            self.restart = False
        #
        with MySQLDriver(self.driver_option) as driver:
            if not driver.is_connected():
                raise DriverError("MySQLDriver connection disconnected.")
            with pika.BlockingConnection(
                parameters=pika.ConnectionParameters(
                    host=self.broker_option.host,
                    port=self.broker_option.port,
                    virtual_host=self.broker_option.virtual_host,
                    heartbeat=3600,
                    credentials=pika.PlainCredentials(
                        username=self.broker_option.user,
                        password=self.broker_option.password,
                    ),
                    client_properties={"label": self.machine_id},
                )
            ) as broker:
                log.info(f"broker connected.")
                channel = broker.channel()
                queue = QUEUE.format(machine_id=self.machine_id)
                route = ROUTE.format(machine_id=self.machine_id)
                log.info(f"Setting exchange={EXCHANGE}, queue={queue}, route={route}")
                #
                channel.exchange_declare(
                    exchange=EXCHANGE, exchange_type="topic", durable=True
                )
                channel.queue_declare(queue=queue, durable=True)
                channel.queue_bind(exchange=EXCHANGE, queue=queue, routing_key=route)
                channel.confirm_delivery()
                #
                started, interval = 0, 60
                while not self.interrupted:
                    try:
                        time.sleep(0.5)
                    except KeyboardInterrupt:
                        break
                    if self.restart:
                        return
                    if TimeUtils.timestamp() - started > interval:
                        try:
                            self.recipe_task(driver, channel, queue)
                        finally:
                            started = TimeUtils.timestamp()
                    self.handle_signals()

    def stop(self):
        log.info(f"stopped.")


def run_forever(config, vhost, level):
    log_level = LogLevel.gets(level)
    handle_stdout(log_level)
    proc = Program(config=config, vhost=vhost)
    try:
        proc.run_forever()
    except Exception as err:
        log.exception(err)
    finally:
        proc.stop()
