import datetime
import time
from typing import List, Dict, Set

import pika
import pika.exceptions

from openlab.compat import BrokerOption, DriverOption
from openlab.compat import DataUtils, TimeUtils, ConfigUtils, CryptoUtils
from openlab.compat import DriverError, BrokerError
from openlab.compat import IMySQLDriver
from openlab.compat import IProgram
from openlab.compat import log, LogLevel, handle_stdout, log_record
from openlab.proto import message_pb2

EXCHANGE = "Situation"
QUEUE = "{module}_Situation"
ROUTE = "{module}.situation"


class MySQLDriver(IMySQLDriver):
    table_tasks = "im_task"
    table_accounts = "im_self_account"

    def __str__(self):
        return (
            f"<MySQLDriver "
            f"host={self.option.host}, "
            f"port={self.option.port}, "
            f"database={self.option.database}, "
            f"connected={self.is_connected()}>"
        )

    def query_modified_tasks(self):
        try:
            sql = (
                "SELECT id, "
                "batch_id, task_id, category, domain,"
                "param1, param2, task_status,"
                "exception_info, command, update_time "
                "FROM im_task "
                f"WHERE is_gathered = 0 "
                "ORDER BY id DESC;"
            )
            rows: List[Dict] = self.querys(sql)
            for row in rows:
                for field, value in row.items():
                    if isinstance(value, (int, float)):
                        continue
                    if value is None:
                        row[field] = ""
                    if isinstance(value, datetime.datetime):
                        row[field] = str(value)
            return rows
        except Exception as err:
            raise DriverError(err)

    def query_modified_accounts(self):
        try:
            sql = (
                "SELECT id,"
                "account_id, area_code, account, password, category, domain,"
                "token1, token2, create_time, status, "
                "is_allocated, allocate_server_ip, device_info,"
                "total_amount, valid_amount, today_amount,"
                "lastest_update_time, next_update_time, direct, source "
                "FROM im_self_account "
                f"WHERE is_gathered = 0;"
            )
            rows: List[Dict] = self.querys(sql)
            for row in rows:
                for field, value in row.items():
                    if isinstance(value, (int, float)):
                        continue
                    if value is None:
                        row[field] = ""
                    if isinstance(value, datetime.datetime):
                        row[field] = str(value)
            return rows
        except Exception as err:
            raise DriverError(err)

    def update_tasks(self, row_ids: list):
        if not row_ids:
            return
        try:
            sql = f"UPDATE {self.table_tasks} SET is_gathered = 1 WHERE id = %s;"
            return self.updatemany(sql, row_ids)
        except Exception as err:
            raise DriverError(err)

    def update_accounts(self, row_ids: list):
        if not row_ids:
            return
        try:
            sql = f"UPDATE {self.table_accounts} SET is_gathered = 1 WHERE id = %s;"
            return self.updatemany(sql, row_ids)
        except Exception as err:
            raise DriverError(err)


class SituationMixin:
    def recipe_situation(self, driver, channel, routing_key):
        log.debug("[Situation]: started")
        situation = message_pb2.Situation()
        situation.hostname = DataUtils.hostname()
        self.prepare_modified_tasks(driver, situation)
        self.prepare_modified_accounts(driver, situation)
        raw = situation.SerializeToString()
        raw_enc = CryptoUtils.encrypt(raw)
        if not raw_enc:
            raise RuntimeError("Encrypt heartbeat failed.")
        raw_enc_zip = DataUtils.ZIP(raw_enc)
        if not raw_enc_zip:
            raise RuntimeError("ZIP heartbeat faileid.")
        log.debug(f"[Situation] size: {DataUtils.format_size(len(raw_enc_zip))}")
        #
        packet = message_pb2.Packet()
        packet.timestamp = TimeUtils.timestamp()
        packet.label = DataUtils.hostname()
        packet.filehash = DataUtils.MD5(raw_enc_zip)
        packet.filename = f"{TimeUtils.timestamp(13)}_{DataUtils.hostname()}.situation"
        packet.msg_type = message_pb2.MSGTYPE.heartbeat
        packet.raw = raw_enc_zip
        body = packet.SerializeToString()

        if not (channel and channel.is_open):
            raise BrokerError("connection or channel not available during situation.")
        try:
            channel.basic_publish(
                exchange=EXCHANGE,
                body=body,
                properties=pika.BasicProperties(delivery_mode=2),
                routing_key=routing_key,
                mandatory=True,
            )
            log.info(
                f"[Situation] [UP] size: {DataUtils.format_size(len(body))}, hash: {packet.filehash}."
            )
        except pika.exceptions.AMQPError as err:
            raise BrokerError(err)

    def prepare_modified_tasks(self, driver, situation):
        tasks = driver.query_modified_tasks()
        log.debug(f"[Situation] modified_tasks: {len(tasks)}.")
        row_ids = set()
        for _task in tasks:
            log.debug(f"[Situation] <Task {_task}>.")
            task = situation.tasks.add()
            row_ids.add(_task.pop("id"))
            #
            task.batch_id = _task["batch_id"]
            task.task_id = _task["task_id"]
            task.category = _task["category"]
            task.domain = _task["domain"]
            task.param1 = _task["param1"]
            param2 = DataUtils.get_values(_task, "param2", None)
            if not param2 or param2 in ("null", "NULL"):
                param2 = "{}"
            task.param2 = param2
            task.task_status = _task["task_status"]
            task.exception_info = _task["exception_info"]
            task.command = _task["command"]
            task.update_time = _task["update_time"]
            task.server_ip = DataUtils.hostname()

        row_ids = [(rid,) for rid in row_ids]
        effected = driver.update_tasks(row_ids)
        log.debug(f"[Situation] lock task: {effected}")

    def prepare_modified_accounts(self, driver, situation):
        accounts = driver.query_modified_accounts()
        log.debug(f"[Situation] modified_accounts: {len(accounts)}")
        row_ids = set()
        for _account in accounts:
            log.debug(f"[Situation]: <Account {_account}>.")
            account = situation.accounts.add()
            row_ids.add(_account.pop("id"))
            #
            account.account_id = _account["account_id"]
            account.category = _account["category"]
            account.domain = _account["domain"]
            account.area_code = _account["area_code"]
            account.account = _account["account"]
            account.password = _account["password"]
            account.token1 = _account["token1"]
            account.token2 = _account["token2"]
            account.create_time = _account["create_time"]
            account.status = _account["status"]
            account.is_allocated = _account["is_allocated"]
            account.allocate_server_ip = DataUtils.hostname()
            account.device_info = _account["device_info"]
            account.total_amount = _account["total_amount"]
            account.valid_amount = _account["valid_amount"]
            account.today_amount = _account["today_amount"]
            account.lastest_update_time = _account["lastest_update_time"]
            account.next_update_time = _account["next_update_time"]
            account.direct = _account["direct"]
            account.source = _account["source"]
        row_ids = [(rid,) for rid in row_ids]
        effected = driver.update_accounts(row_ids)
        log.debug(f"[Situation] lock account: {effected}")


class Program(IProgram, SituationMixin):
    def __init__(self, *args, **kwargs):
        super(Program, self).__init__()
        self.module = kwargs["module"]
        self.cfgpath = kwargs["config"]
        self.dbname = kwargs["dbname"]
        self.vhost = kwargs["vhost"]
        self.configs = {}
        #
        self.broker_option = None
        self.driver_option = None
        self.load_config()

    def load_config(self):
        self.configs.clear()
        self.configs = ConfigUtils.load_config(self.cfgpath)
        driver = DataUtils.get_values(self.configs, "DRIVER")
        self.driver_option = DriverOption.load(driver)
        if self.dbname:
            self.driver_option.database = self.dbname
        log.info(f"{self.driver_option}")
        broker = DataUtils.get_values(self.configs, "BROKER")
        self.broker_option = BrokerOption.load(broker)
        if self.vhost:
            self.broker_option.virtual_host = self.vhost
        log.info(f"{self.broker_option}")

    def working(self):
        log.info(f"started {self.module}")
        if self.restart:
            self.load_config()
            self.restart = False
        with MySQLDriver(self.driver_option) as driver:
            if not driver.is_connected():
                raise DriverError("MySQLDriver connection disconnected.")
            with pika.BlockingConnection(
                parameters=pika.ConnectionParameters(
                    host=self.broker_option.host,
                    port=self.broker_option.port,
                    virtual_host=self.broker_option.virtual_host,
                    heartbeat=3600,
                    credentials=pika.PlainCredentials(
                        username=self.broker_option.user,
                        password=self.broker_option.password,
                    ),
                    client_properties={"label": f"situation_{self.machine_id}"},
                )
            ) as broker:
                log.info(f"broker connected.")
                channel = broker.channel()
                queue = QUEUE.format(module=self.module.upper())
                route = ROUTE.format(module=self.module.lower())
                log.info(f"Setting exchange={EXCHANGE}, queue={queue}, route={route}")
                channel.exchange_declare(
                    exchange=EXCHANGE, exchange_type="topic", durable=True
                )
                channel.queue_declare(queue=queue, durable=True)
                channel.queue_bind(exchange=EXCHANGE, queue=queue, routing_key=route)
                channel.confirm_delivery()
                #
                started, interval = 0, 90
                while not self.interrupted:
                    try:
                        time.sleep(0.5)
                    except KeyboardInterrupt:
                        break
                    self.handle_signals()
                    if self.restart:
                        return
                    #
                    if TimeUtils.timestamp() - started > interval:
                        try:
                            self.recipe_situation(driver, channel, route)
                        finally:
                            started = TimeUtils.timestamp()
                    self.handle_signals()

    def stop(self):
        log.info(f"stop {self.module}")


def run_forever(module: str, config_path: str, vhost: str, dbname: str, level: str):
    log_level = LogLevel.gets(level)
    handle_stdout(log_level)
    proc = Program(module=module, config=config_path, vhost=vhost, dbname=dbname)
    try:
        proc.run_forever()
    except Exception as err:
        log.exception(err)
    finally:
        proc.stop()
