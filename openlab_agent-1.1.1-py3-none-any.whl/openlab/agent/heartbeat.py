import datetime
import time
from typing import List, Dict, Set

import pika
import pika.exceptions

from openlab.compat import BrokerOption, DriverOption
from openlab.compat import DataUtils, TimeUtils, ConfigUtils, CryptoUtils
from openlab.compat import DriverError, BrokerError
from openlab.compat import IMySQLDriver
from openlab.compat import IProgram
from openlab.compat import log, LogLevel, handle_stdout, log_record
from openlab.proto import message_pb2

EXCHANGE = "Heartbeat"
QUEUE = "{module}_Heartbeat"
ROUTE = "{module}.heartbeat"


class MySQLDriver(IMySQLDriver):
    table_tasks = "im_task"
    table_accounts = "im_self_account"

    def aggregate_category_domain(self) -> Dict[int, Set[int]]:
        # Dict[category, [domain1, domain2, ...]
        v = {}
        for table in (self.table_tasks, self.table_accounts):
            sql = f"select DISTINCT category, domain from {table} order by category, domain;"
            for row in self.querys(sql):
                category, domain = row["category"], row["domain"]
                if category not in v.keys():
                    v[category] = []
                if domain not in v[category]:
                    v[category].append(domain)
        return v

    def aggregate_tasks(self, category, domain):
        try:
            sql = (
                "SELECT "
                "task_status AS status, "
                "task_priority AS priority, "
                "count( id ) AS count "
                "FROM im_task WHERE "
                f"command = 1 AND "
                f"category = {category} AND "
                f"domain = {domain} "
                "GROUP BY task_status, task_priority;"
            )
            return self.querys(sql)
        except Exception as err:
            raise DriverError(err)

    def aggregate_accounts(self, category, domain):
        try:
            sql = (
                "SELECT "
                "status, "
                "is_allocated AS allocated, "
                "count(id) AS count "
                "FROM im_self_account WHERE "
                f"category = {category} AND "
                f"domain = {domain} "
                "GROUP BY status, is_allocated;"
            )
            return self.querys(sql)
        except Exception as err:
            raise DriverError(err)


class HeartbeatMixin:
    @log_record
    def recipe_heartbeat(self, driver: MySQLDriver, channel, routing):
        mappings = driver.aggregate_category_domain()
        for category, domains in mappings.items():
            for domain in domains:
                try:
                    self.prepare_heartbeat(category, domain, driver, channel, routing)
                except pika.exceptions.AMQPError as err:
                    raise BrokerError(err)
                except Exception as err:
                    log.exception(err)

    @log_record
    def prepare_heartbeat(self, category, domain, driver, channel, route):
        log.info(f"[Heartbeat] category: {category}, domain: {domain}.")
        heartbeat = message_pb2.Heartbeat()
        heartbeat.category = category
        heartbeat.domain = domain
        heartbeat.hostname = DataUtils.hostname()
        ##
        tasks = driver.aggregate_tasks(category, domain)
        for _task in tasks:
            log.debug(f"[Heartbeat] --> Task: {_task}")
            task = heartbeat.tasks.add()
            task.status = _task["status"]
            task.priority = _task["priority"]
            task.count = _task["count"]
        accounts = driver.aggregate_accounts(category, domain)
        for _account in accounts:
            log.debug(f"[Heartbeat] --> Account: {_account}")
            account = heartbeat.accounts.add()
            account.status = _account["status"]
            account.allocated = _account["allocated"]
            account.count = _account["count"]
        ##
        raw = heartbeat.SerializeToString()
        raw_enc = CryptoUtils.encrypt(raw)
        if not raw_enc:
            raise RuntimeError("Encrypt heartbeat failed.")
        raw_enc_zip = DataUtils.ZIP(raw_enc)
        if not raw_enc_zip:
            raise RuntimeError("ZIP heartbeat faileid.")
        log.debug(f"[Heartbeat] size: {DataUtils.format_size(len(raw_enc_zip))}")
        ##
        packet = message_pb2.Packet()
        packet.msg_type = message_pb2.MSGTYPE.heartbeat
        packet.timestamp = TimeUtils.timestamp()
        packet.label = DataUtils.hostname()
        packet.filehash = DataUtils.MD5(raw_enc_zip)
        packet.filename = f"C{category}D{domain}_{DataUtils.hostname()}.heartbeat"
        packet.raw = raw_enc_zip
        body = packet.SerializeToString()
        #
        if not (channel and channel.is_open):
            raise BrokerError("connection or channel not available during heartbeat.")
        try:
            channel.basic_publish(
                exchange=EXCHANGE,
                body=body,
                properties=pika.BasicProperties(delivery_mode=2),
                routing_key=route,
                mandatory=True,
            )
            log.info(
                f"[Heartbeat] [UP] size: {DataUtils.format_size(len(body))}, hash: {packet.filehash}."
            )
        except pika.exceptions.AMQPError as err:
            raise BrokerError(err)


class Program(IProgram, HeartbeatMixin):
    def __init__(self, *args, **kwargs):
        super(Program, self).__init__()
        self.configs = {}
        self.broker_option = None
        self.driver_option = None
        #
        self.module = kwargs["module"]
        self.cfgpath = kwargs["config"]
        self.dbname = kwargs["dbname"]
        self.vhost = kwargs["vhost"]
        #
        self.load_config()

    def load_config(self):
        log.info(f"loading {self.cfgpath}.")
        self.configs.clear()
        self.configs = ConfigUtils.load_config(self.cfgpath)
        driver = DataUtils.get_values(self.configs, "DRIVER")
        self.driver_option = DriverOption.load(driver)
        if self.dbname:
            self.driver_option.database = self.dbname

        log.info(f"{self.driver_option}")
        broker = DataUtils.get_values(self.configs, "BROKER")
        self.broker_option = BrokerOption.load(broker)
        if self.vhost:
            self.broker_option.virtual_host = self.vhost
        log.info(f"{self.broker_option}")

    def working(self):
        log.info(f"started {self.module}")
        if self.restart:
            self.load_config()
            self.restart = False
        ##
        with MySQLDriver(self.driver_option) as driver:
            if not driver.is_connected():
                raise DriverError("MySQLDriver connection disconnected.")
            log.info(f"<MySQLDriver connected>.")
            ##
            with pika.BlockingConnection(
                parameters=pika.ConnectionParameters(
                    host=self.broker_option.host,
                    port=self.broker_option.port,
                    virtual_host=self.broker_option.virtual_host,
                    heartbeat=3600,
                    credentials=pika.PlainCredentials(
                        username=self.broker_option.user,
                        password=self.broker_option.password,
                    ),
                    client_properties={"label": f"heartbeat_{self.machine_id}"},
                )
            ) as broker:
                log.info(f"<Broker connected>.")
                channel = broker.channel()
                queue = QUEUE.format(module=self.module.upper())
                route = ROUTE.format(module=self.module.lower())
                log.info(f"Setting exchange={EXCHANGE}, queue={queue}, route={route}")
                channel.exchange_declare(
                    exchange=EXCHANGE, exchange_type="topic", durable=True
                )
                channel.queue_declare(queue=queue, durable=True)
                channel.queue_bind(exchange=EXCHANGE, queue=queue, routing_key=route)
                channel.confirm_delivery()
                #
                started, interval = 0, 60
                while not self.interrupted:
                    try:
                        time.sleep(0.5)
                    except KeyboardInterrupt:
                        break
                    #
                    self.handle_signals()
                    if self.restart:
                        return
                    #
                    if TimeUtils.timestamp() - started > interval:
                        try:
                            self.recipe_heartbeat(driver, channel, route)
                        finally:
                            started = TimeUtils.timestamp()
                    self.handle_signals()

    def stop(self):
        log.info(f"stop {self.module}")


def run_forever(module: str, config_path: str, vhost: str, dbname: str, level: str):
    log_level = LogLevel.gets(level)
    handle_stdout(log_level)
    proc = Program(module=module, config=config_path, vhost=vhost, dbname=dbname)
    try:
        proc.run_forever()
    except Exception as err:
        log.exception(err)
    finally:
        proc.stop()
