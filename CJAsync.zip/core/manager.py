import copy
from threading import Lock
import yaml
import os
import sys

from common.sqlitedriver import SQLiteHelper
from common.utils import load_object, CryptoUtils, DataUtils, TimeUtils

DBManager = SQLiteHelper.instance()


def load_config(path):
    config = {}
    with open(path, "r") as fd:
        config = yaml.load(fd, Loader=yaml.FullLoader)

    for name, values in config.items():
        if name in ("MQ", "MYSQL", "MONGO"):
            decrypt = DataUtils.get_value(values, "DECRYPT", True)
            if not decrypt:
                continue
            for key in config[name].keys():
                config[name][key] = CryptoUtils.decrypt_data(config[name][key])

    return config


class Manager:
    _instance_lock = Lock()
    _plugin_lock = Lock()
    RUNNING_PLUGINS = {
        # uid: {"config": "", insta: object}
    }

    @classmethod
    def instance(cls):
        if not hasattr(cls, "_instance"):
            with Manager._instance_lock:
                if not hasattr(cls, "_instance"):
                    Manager._instance = Manager()
        return Manager._instance

    def init(self):
        rows = DBManager.query()
        for row in rows:
            self.start_plugin(row["name"], row["config"])

    def start_plugin(self, name, config):
        path = os.path.join(os.getcwd(), "config", config)
        if not os.path.exists(path):
            return None

        uid = None
        with open(path, "rb") as fd:
            data = fd.read()
            uid = DataUtils.get_md5(data)

        if uid is None or uid in self.RUNNING_PLUGINS.keys():
            return None

        module_path = f"plugins.{name}"
        conf = load_config(path)
        try:
            clazz = load_object(module_path)
            obj = clazz(name=uid, config=conf)
            obj.start()
        except Exception as err:
            import traceback

            traceback.print_exc()
            return str(err)
        else:
            with Manager._plugin_lock:
                self.RUNNING_PLUGINS[uid] = {
                    "name": name,
                    "start_time": TimeUtils.strtime(),
                    "inst": obj,
                    "config": config,
                }
                DBManager.add(uid, name, config)
                DBManager.plugin_started(uid)
            return uid

    def stop_plugin(self, uid):
        if uid not in self.RUNNING_PLUGINS.keys():
            return False

        with Manager._plugin_lock:
            items = self.RUNNING_PLUGINS.pop(uid)
            name = items["name"]
            inst = items["inst"]

            pyname = name.split(".", 1)[0]
            module = ".".join(["plugins", pyname])
            if module in sys.modules:
                sys.modules.pop(module)

            inst.shutdown()
            inst.join()
            DBManager.plugin_stopped(uid)
        return True

    def check_plugins(self):
        infos = []
        for uid, items in self.RUNNING_PLUGINS.items():
            infos.append(
                f"UID: {uid}, Plugin: {items['config']} - {items['name']}, Start: {items['start_time']}"
            )
        return infos

    def delete_plugin(self, uid):
        self.stop_plugin(uid)
        DBManager.delete(uid)

    def update_plugin(self, uid, name, config):
        self.stop_plugin(uid)
        DBManager.delete(uid)
        return self.start_plugin(name, config)

    def shutdown(self):
        uids = copy.copy(list(self.RUNNING_PLUGINS.keys()))
        for uid in uids:
            self.stop_plugin(uid)
