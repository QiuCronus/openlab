if __name__ == "__main__":
    from app import start_app

    start_app()
