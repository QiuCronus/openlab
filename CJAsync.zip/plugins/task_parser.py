import os
import shutil
import time

from common.base import IPlugins
from common.mysql import MySQLHelper
from common.utils import DataUtils, LoggerFactory, TimeUtils, CryptoUtils


class TaskParseThread(IPlugins):
    VERSION = "20210120"

    def __init__(self, name, config: dict):
        super(TaskParseThread, self).__init__(name, config)
        self.interval = 30
        self._start_timestamp = TimeUtils.timestamp()
        self.name = f"TaskParseThread-{name}"
        self.paths = []

    def handle_exception(self, exception):
        if self.logger:
            self.logger.exception(exception)

    def status(self):
        return ""

    def prepare(self):
        default = DataUtils.get_value(self.config, "GLOBAL", {})
        self.category = DataUtils.get_value(default, "CATEGORY", 0)
        self.domain = DataUtils.get_value(default, "DOMAIN", 0)
        self.dtype = DataUtils.get_value(default, "DATA_TYPE", 0)
        self.module = DataUtils.get_value(default, "MODULE", "default")
        #
        self.local_ip = DataUtils.get_local_ip()
        self.ip_addr_hash = DataUtils.get_md5(self.local_ip)
        #
        self.name = f"{self.category}-{self.domain}-{self.dtype}-{self.name}"
        self.logger = LoggerFactory.initialize(self.name)
        #
        self.logger.debug(f"Version: {self.VERSION}")
        self.logger.debug(f"MachineID: {self.ip_addr_hash}")
        #
        self.dirpath = DataUtils.get_value(default, "PARSE_PATH", None)
        if self.dirpath is None:
            self.dirpath = os.path.join(
                os.getcwd(),
                "Data",
                "MQ",
                "Receive",
                str(self.category),
                str(self.domain),
            )
        DataUtils.ensure_dir(self.dirpath)
        #
        self.err_dir = os.path.join(
            os.getcwd(), "Data", "Error", "Parse", str(self.category), str(self.domain)
        )
        DataUtils.ensure_dir(self.err_dir)

        self.logger.debug(
            f"Category: {self.category}, Domain: {self.domain}, DataType: {self.dtype}"
        )
        self.logger.debug(f"Directory Scan: {self.dirpath}")
        self.logger.debug(f"Directory Error: {self.err_dir}")

        self.dbname = DataUtils.get_value(self.config["MYSQL"], "DBNAME", None)
        if self.dbname is None:
            self.dbname = f"im_{self.category}_{self.domain}"
        self.logger.debug(f"DBNAME: {self.dbname}")

    def dismiss(self):
        self.logger.info(f"{self.name} STOPPED.")

    def working(self):
        self.logger.debug(f"TaskParser::working(): started.")
        if not self.dbname:
            self.logger.error(f"Could not load related db from setting, exit!!")
            self.stopping = True
            return

        dbconf = DataUtils.get_value(self.config, "MYSQL", None)
        interval, started = 60, 0
        while not self.stopping:
            try:
                time.sleep(0.5)
            except Exception as err:
                self.logger.exception(err)
                return

            if TimeUtils.timestamp() - started > interval:
                try:
                    with MySQLHelper(
                            host=dbconf["HOST"],
                            port=int(dbconf["PORT"]),
                            user=dbconf["USER"],
                            passwd=dbconf["PASSWD"],
                            dbname=self.dbname,
                    ) as database:
                        if not database.is_connected():
                            raise RuntimeError("database connection disconnect.")
                        self._parse_recipe(database)
                except Exception as err:
                    self.logger.exception(err)
                finally:
                    started = TimeUtils.timestamp()

    def _parse_recipe(self, database: MySQLHelper):
        self.logger.debug("TaskParser::_parse_recipe(): started.")
        started = 0

        launch = TimeUtils.timestamp()
        while not self.stopping:
            try:
                time.sleep(0.5)
            except Exception as err:
                self.logger.exception(err)
                return

            if TimeUtils.timestamp() - launch > 4 * 3600:
                return

            if TimeUtils.timestamp() - started > self.interval:
                try:
                    self.prepare_message()
                    if len(self.paths) > 0:
                        self._parse(database)
                finally:
                    started = TimeUtils.timestamp()

    def _parse(self, database: MySQLHelper):
        self.logger.debug(f"Ready to handle: {len(self.paths)} files ...")
        while len(self.paths) > 0:
            path = self.paths[0]
            # path = self.paths.pop(0)
            if not os.path.exists(path):
                self.paths.remove(path)
                self.logger.error(f"file not exists: {path}")
                continue

            _, filename = os.path.split(path)
            if os.path.getsize(path) == 0:
                self.logger.warning(f"{path} is empty, remove it.")
                os.remove(path)
                self.paths.remove(path)
                continue

            content = self.load_content(path)
            if not content:
                n_path = os.path.join(self.err_dir, filename)
                shutil.move(path, n_path)
                self.logger.warning(f"load {path} failed.")
                self.paths.remove(path)
                continue

            hash = DataUtils.get_md5(content)
            try:
                tasks = self.handle_data(content)
            except Exception as err:
                self.logger.exception(err)
                n_path = os.path.join(self.err_dir, filename)
                shutil.move(path, n_path)
                self.paths.remove(path)
                self.logger.warning(f"handle {path} failed, move to Error.")
            else:
                self.logger.debug(
                    f"[PARSED] extract {len(tasks)} task record from file={filename}; hash={hash}"
                )
                if not tasks:
                    n_path = os.path.join(self.err_dir, filename)
                    shutil.move(path, n_path)
                    self.paths.remove(path)
                    self.logger.warning(f"Generate task record failed. move to Error.")
                    continue

                for task in tasks:
                    batch_id = DataUtils.get_value(task, "batch_id")
                    task_id = DataUtils.get_value(task, "task_id")
                    category = int(DataUtils.get_value(task, 'category'))
                    domain = int(DataUtils.get_value(task, "domain"))
                    ret, size = database.task_exists(batch_id, task_id, category, domain)
                    if ret is False:
                        raise RuntimeError(f"add_file={filename}, error={size}")
                    if size > 0:
                        database.delete_task(batch_id, task_id, category, domain)

                    res = database.add_tasks([task])
                    if res is False:
                        raise RuntimeError(f"add file={filename}; hash={hash} failed.")

                self.logger.debug(
                    f"add file={filename}; hash={hash}; size={len(tasks)} success."
                )
                os.remove(path)
                self.paths.remove(path)

    def prepare_message(self, limit=10):
        self.logger.debug("TaskParser::prepare_message(): invoked.")
        if len(self.paths) > limit:
            return

        for root, dirs, names in os.walk(self.dirpath):
            for name in names:
                if len(self.paths) >= limit:
                    return
                path = os.path.join(root, name)
                if path not in self.paths:
                    self.paths.append(path)

    def load_content(self, path):
        try:
            with open(path, "rb") as fd:
                return fd.read()
        except Exception as err:
            self.logger.exception(err)
            return None

    def handle_data(self, data: bytes):
        data = DataUtils.zlib_decompress(data)
        if not data:
            raise RuntimeError("decompress file failed.")

        decrypted = CryptoUtils.decrypt_data(data)
        if decrypted != 0:
            raise RuntimeError("decrypt file failed.")

        strdata = data.decode("UTF-8")
        unpacked = DataUtils.unpack(strdata)
        if not unpacked:
            raise RuntimeError("unpack file failed.")

        return self.generate_tasks(unpacked)

    def generate_tasks(self, data: dict):
        command = int(DataUtils.get_value(data, "command", -1))
        details = DataUtils.get_value(data, "details", [])
        tasks = [
            {
                "batch_id":      DataUtils.get_value(line, "batch_id", None),
                "task_id":       DataUtils.get_value(line, "task_id", None),
                "target":        DataUtils.get_value(line, "target", None),
                "category":      DataUtils.get_value(line, "category", 0),
                "domain":        DataUtils.get_value(line, "domain", 0),
                "param1":        DataUtils.get_value(line, "param1", "{}"),
                "param2":        DataUtils.get_value(line, "param2", ""),
                "command":       command,
                "update_time":   TimeUtils.strtime(),
                "server_ip":     self.local_ip,
                "task_status":   0,
                "task_priority": 0,
                "is_auto_join":  1,
                "is_gathered":   0,
                "is_deleted":    0,
                "use_count":     0,
                "is_dispatched": 1,
                "gather_time":   TimeUtils.timestamp(),
            }
            for line in details
        ]
        avail_tasks = [
            d
            for d in tasks
            if d["batch_id"]
               and d["task_id"]
               and d["target"]
               and int(d["category"]) > 0
               and int(d["domain"]) > 0
        ]
        return avail_tasks
