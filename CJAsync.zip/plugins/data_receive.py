"""
Retrieve Data From AMQP Server (Task)
Enable send Heartbeat Packet to request Task Data.
"""
import copy
import json
import os
import time

import pika
import pika.frame
import pika.spec
from pika.adapters.blocking_connection import BlockingChannel
from pika.adapters.blocking_connection import BlockingConnection
from pika.exceptions import NackError
from pika.exceptions import UnroutableError


from common.base import IPlugins
from common.keeper import ConnectionKeeperThread
from common.mysql import MySQLHelper
from common.utils import LoggerFactory, DataUtils, TimeUtils, CryptoUtils


class DriverConnectionError(Exception):
    pass


class DataReceiveService(IPlugins):
    VERSION = '20210120'

    def __init__(self, name: str, config: dict):
        super(DataReceiveService, self).__init__(name, config)
        self.name = f"DataReceiveService-{name}"
        self.alarm_disk_space_line = 100 * 1024 * 1024  # 100MB
        self.reconnect_delay = 60
        self.last_heartbeat_timestamp = 0

    def handle_exception(self, exception):
        if self.logger:
            self.logger.exception(exception)

    def version(self):
        return self.VERSION

    def status(self):
        return ""

    def prepare(self):
        gconf = DataUtils.get_value(self.config, 'GLOBAL', {})
        self.category = DataUtils.get_value(gconf, 'CATEGORY', 0)
        self.domain = DataUtils.get_value(gconf, 'DOMAIN', 0)
        self.dtype = DataUtils.get_value(gconf, 'DATA_TYPE', 0)
        if self.category == 0 or self.domain == 0:
            self.stopping = True
            return
        #
        self.ip_addr = DataUtils.get_local_ip()
        self.ip_addr_hash = DataUtils.get_md5(self.ip_addr)

        self.name = f"{self.category}-{self.domain}-{self.dtype}-{self.name}"
        self.logger = LoggerFactory.initialize(self.name)
        #
        self.logger.debug(f"Version: {self.VERSION}")
        self.logger.debug(f"MachineID: {self.ip_addr_hash}")
        #
        self.module = DataUtils.get_value(gconf, "MODULE", "default")
        self.enable_parse_header = DataUtils.get_value(gconf, 'PARSE_HEADER', False)
        #
        self.enable_heartbeat = DataUtils.get_value(gconf, 'ENABLE_HEARTBEAT', True)
        self.enable_limit_heartbeat = DataUtils.get_value(gconf, 'ENABLE_LIMIT_HEARTBEAT', False)
        self.heartbeat_interval = DataUtils.get_value(gconf, 'HEARTBEAT_INTERVAL', 300)
        self.heartbeat_limit = DataUtils.get_value(gconf, 'HEARTBEAT_LIMIT', 200)
        self.distribute_max_size = DataUtils.get_value(gconf, 'DISTRIBUTE_MAX', 5000)
        self.distribute_max_size = min(50000, self.distribute_max_size)
        self.trigger_threshold = DataUtils.get_value(gconf, 'TRIGGER_THRESHOLD', 0.2)
        self.depend_account = bool(DataUtils.get_value(gconf, "DEPEND_ACCOUNT", True))
        #
        self.dir_recv = DataUtils.get_value(gconf, 'RECEIVE_PATH', None)
        self.dir_recv = self.dir_recv or os.path.join(os.getcwd(),
                                                      "Data", "MQ", "Receive",
                                                      str(self.category), str(self.domain))
        self.dir_recv = os.path.normpath(self.dir_recv)
        DataUtils.ensure_dir(self.dir_recv)
        #
        self.logger.debug(f"Category={self.category},Domain={self.domain},DataType={self.dtype}")
        self.logger.debug(f"Enable Parsing FileHeader: {self.enable_parse_header}")
        if self.enable_heartbeat:
            self.logger.debug("Turn on the heartbeat mechanism.")
            self.logger.debug(f"Heartbeat Interval: {self.heartbeat_interval}s")
            if self.enable_limit_heartbeat:
                self.logger.debug("Maximum length of open heartbeat queue.")
                self.logger.debug(f"Heartbeat queue size: {self.heartbeat_limit}")
        self.logger.debug(f"Maximum number of single request: {self.distribute_max_size}")
        self.logger.debug(f"Trigger request threshold: {self.trigger_threshold}")
        self.logger.debug(f"Receive Store Directory: {self.dir_recv}")
        #
        if 'MYSQL' in self.config.keys():
            self.dbname = DataUtils.get_value(self.config['MYSQL'], 'DBNAME', None)
            self.dbname = self.dbname or f"im_{self.category}_{self.domain}"
            self.logger.debug(f"Data Source DB: {self.dbname}")

    def dismiss(self):
        self.logger.info("stopped.")

    def working(self):
        self.logger.debug("DataReceiveService::working(): started.")
        started = 0
        while not self.stopping:
            try:
                time.sleep(0.5)
            except KeyboardInterrupt:
                return
            #
            if TimeUtils.timestamp() - started > self.reconnect_delay:
                try:
                    self.receive_recipe()
                except Exception as err:
                    self.logger.error(err)
                finally:
                    started = TimeUtils.timestamp()

    def receive_recipe(self):
        if self.enable_heartbeat is False:
            self._receive_recipe()
            return

        dbconf = DataUtils.get_value(self.config, 'MYSQL', {})
        with MySQLHelper(host=dbconf['HOST'],
                         port=int(dbconf['PORT']),
                         user=dbconf['USER'],
                         passwd=dbconf['PASSWD'],
                         dbname=self.dbname) as database:
            while not self.stopping:
                if not database.is_connected():
                    self.logger.error("Database connection disconnected.")
                    return

                try:
                    self._receive_recipe(database)
                except DriverConnectionError as err:
                    self.logger.exception(err)
                    break
                except Exception as err:
                    self.logger.exception(err)

    def _receive_recipe(self, database: MySQLHelper = None):
        rabbitmq = self.config['MQ']
        parameters = pika.ConnectionParameters(
            host=rabbitmq['HOST'],
            port=int(rabbitmq['PORT']),
            virtual_host=rabbitmq['VHOST'],
            credentials=pika.PlainCredentials(
                username=rabbitmq['USER'],
                password=rabbitmq['PASSWD']
            ),
            heartbeat=3600,
        )
        exchange = DataUtils.get_value(rabbitmq, 'EXCHANGE', None)
        queue = DataUtils.get_value(rabbitmq, "QUEUE", None)
        route = DataUtils.get_value(rabbitmq, "ROUTE", None)

        if exchange is None:
            self.logger.error(f"Could not load AMQP `EXCHANGE`, exit!")
            self.stopping = True
            return

        queue = queue or f"C{self.category}D{self.domain}_file_task_{self.ip_addr_hash}"
        route = route or f"C{self.category}D{self.domain}_file_{self.ip_addr_hash}"
        self.logger.debug(f"Exchange: {exchange}, Queue: {queue}, Route: {route}")

        with pika.BlockingConnection(parameters) as connection:
            self.logger.debug(f"amqp connection: {id(connection)}")
            try:
                #
                if self.enable_heartbeat:
                    channel_h = connection.channel()
                    channel_h.exchange_declare(exchange=exchange,
                                               durable=True, exchange_type='topic')
                    arguments = {}
                    if self.enable_limit_heartbeat:
                        arguments['x-max-length'] = int(self.heartbeat_limit)

                    channel_h.queue_declare(queue="queue_heartbeat",
                                            durable=True, arguments=arguments)
                    channel_h.queue_bind(exchange=exchange,
                                         queue="queue_heartbeat",
                                         routing_key="heartbeat.tc")
                    channel_h.confirm_delivery()
                else:
                    channel_h = None
                #
                channel_r = connection.channel()
                channel_r.exchange_declare(exchange=exchange, exchange_type="topic", durable=True)
                channel_r.queue_declare(queue=queue, durable=True)
                channel_r.queue_bind(exchange=exchange, queue=queue, routing_key=route)
                #
                self._retrieve(database, connection, channel_h, channel_r, exchange, queue)
            except DriverConnectionError as err:
                raise DriverConnectionError(err)

            except Exception as err:
                self.handle_exception(err)
                return

    def _retrieve(self,
                  database: MySQLHelper,
                  connection,
                  channel_heartbeat,
                  channel_recv,
                  exchange, queue):
        self.logger.debug("DataReceiveService::_retrieve(): invoked.")

        started, interval, heartbeat = 0, 10, 0
        launch = TimeUtils.timestamp()
        while not self.stopping:
            try:
                time.sleep(0.5)
            except Exception as err:
                self.logger.exception(err)
                return

            if TimeUtils.timestamp() - launch > 3600 * 4:
                return

            if TimeUtils.timestamp() - started > interval:
                try:
                    if DataUtils.get_free_disk() < self.alarm_disk_space_line:
                        self.logger.warning(f"[DISK ALARM] disk space is below threshold, "
                                            f"will blocking generate recipe until alarm dismiss.")
                        interval = 300
                        continue
                    else:
                        interval = 10
                        self._receive_files(connection, channel_recv, queue)
                finally:
                    started = TimeUtils.timestamp()

            if self.enable_heartbeat and TimeUtils.timestamp() - heartbeat > self.heartbeat_interval:
                if not (
                        channel_heartbeat
                        and channel_heartbeat.is_open
                        and connection
                        and connection.is_open
                ):
                    raise RuntimeError("amqp connection or heartbeat channel are not available.")
                try:
                    self._prepare_heartbeat(database, channel_heartbeat, exchange)
                finally:
                    heartbeat = TimeUtils.timestamp()

    def _prepare_heartbeat(self, database: MySQLHelper, channel, exchange):
        self.logger.debug(f"DataReceive::prepare_heartbeat(): invoked.")

        remain_size = 0
        for root, _, names in os.walk(self.dir_recv):
            remain_size += len(names)

        if remain_size > 5:
            self.logger.warning(f"DataReceive::prepare_heartbeat(): {remain_size} file remain in receive directory!!")
            return

        if DataUtils.get_free_disk() < self.alarm_disk_space_line:
            self.logger.warning(f"[DISK ALARM] disk space is below threshold, "
                                f"will blocking generate recipe until alarm dismiss.")
            return

        has_available_tasks = database.count_available_tasks()
        if has_available_tasks < 0:
            if not database.is_connected():
                raise DriverConnectionError("database connection disconnected.")
            self.logger.error(f"count_available_task(): error, size={has_available_tasks}")
            return

        if has_available_tasks > 5:
            self.logger.debug(f"remain {has_available_tasks} task to pending or dealing.(more than 5.)")
            return

        has_available_account = 0
        if self.depend_account:
            has_available_account = database.count_available_accounts()
            if has_available_account <= 0:
                if not database.is_connected():
                    raise DriverConnectionError("database connection disconnected.")

                self.logger.warning("No available account.")
                return
        self.logger.debug(f"DataReceive::prepare_heartbeat(): [TICK]"
                          f"remain_task={has_available_tasks}, "
                          f"remain_account={has_available_account}")
        data = json.dumps({
            'ip':               self.ip_addr,
            'update_time':      TimeUtils.strtime(),
            'disk':             DataUtils.get_free_disk(),
            'category':         self.category,
            'domain':           self.domain,
            'dtype':            self.dtype,
            'distribute_count': 0,
        }, ensure_ascii=False)
        hash = DataUtils.get_md5(data)
        body = {
            "id":   hash,
            "data": data
        }
        packet = json.dumps(body, ensure_ascii=False)

        ###########
        # Encrypt #
        ###########
        encrypted = CryptoUtils.encrypt_data(packet)
        if not encrypted:
            self.logger.error(f"Encrypt heartbeat packet failed.")
            return

        try:
            channel.basic_publish(exchange=exchange,
                                  routing_key="heartbeat.tc",
                                  body=encrypted,
                                  properties=pika.BasicProperties(delivery_mode=2),
                                  mandatory=True)
        except Exception as err:
            self.logger.exception(err)
            self.logger.error("Publish Heartbeat Failed.")

    def _receive_files(self, connection, channel, queue):
        self.logger.debug("DataReceiveService::_receive_files(): invoked.")
        frame = channel.queue_declare(queue=queue, durable=True)  # type: pika.frame.Method
        if frame and frame.method.message_count == 0:
            return

        for _ in range(30):
            if not (
                    channel
                    and channel.is_open
                    and connection
                    and connection.is_open
            ):
                raise RuntimeError("amqp connection or receive channel are not available.")
            #
            method, properties, body = None, None, None
            try:
                method, properties, body = channel.basic_get(queue)
                if method is None or properties is None:
                    return
                if body:
                    self.handle_data(body)
            except Exception as err:
                self.logger.exception(err)
            finally:
                if method:
                    channel.basic_ack(method.delivery_tag)
                    if method.message_count == 0:
                        break

    def handle_data(self, body: bytes):
        if not body:
            return
        filename = f"{TimeUtils.timestamp(13)}_{DataUtils.generateUID()}.dat"
        if self.enable_parse_header:
            header, body = copy.copy(body[:66]), copy.copy(body[66:])
            body_hash = DataUtils.get_md5(body)
            batch_id, filename = self.extract_filename(header)

            filepath = os.path.join(self.dir_recv, batch_id)
            DataUtils.ensure_dir(filepath)

            self.logger.debug(f"[RECV] batch_id={batch_id}, file={filename}, hash={body_hash}")
        else:
            body_hash = DataUtils.get_md5(body)
            self.logger.debug(f"[RECV] file={filename}, hash={body_hash}")
            filepath = self.dir_recv

        filepath = os.path.join(filepath, filename)
        self.logger.debug(f"[STORE] {filepath}")

        with open(filepath, "wb") as fd:
            fd.write(body)

    def extract_filename(self, data: bytes):
        data = DataUtils.bytes2str(data)
        batch_id, name = data.split("&&", 1)
        batch_id = batch_id.replace("#", '')
        name = name.replace("#", '')
        return batch_id, name
