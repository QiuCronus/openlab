import json
import os
import re
import time

from common.base import IPlugins
from common.constants import *
from common.mysql import MySQLHelper
from common.utils import LoggerFactory, DataUtils, TimeUtils, CryptoUtils


class ReconnectError(Exception):
    pass


class DataGenService(IPlugins):
    VERSION = "20210120"

    def __init__(self, name: str, config: dict):
        super(self.__class__, self).__init__(name, config)
        self.name = f"DataGenService-{name}"
        self.alarm_disk_space_line = 100 * 1024 * 1024  # 100MB
        self.retry_delay = 60
        self.packet = {}

    def handle_exception(self, exception):
        if self.logger:
            self.logger.exception(exception)

    def status(self):
        return ""

    def prepare(self):
        default = DataUtils.get_value(self.config, "GLOBAL", {})

        self.category = DataUtils.get_value(default, "CATEGORY", 0)
        self.domain = DataUtils.get_value(default, "DOMAIN", 0)
        self.dtype = DataUtils.get_value(default, "DATA_TYPE", 0)
        self.ip_addr = DataUtils.get_local_ip()
        self.ip_addr_hash = DataUtils.get_md5(self.ip_addr)
        #
        self.name = f"{self.category}-{self.domain}-{self.dtype}-{self.name}"
        self.logger = LoggerFactory.initialize(self.name)
        #
        self.logger.debug(f"Version: {self.VERSION}")
        self.logger.debug(f"MachineID: {self.ip_addr_hash}")
        #
        self.interval = DataUtils.get_value(default, "INTERVAL", 300)
        self.interval = max(10, self.interval)
        self.module = DataUtils.get_value(default, "MODULE", "default")
        #self.enable_clear = DataUtils.get_value(default, "ENABLE_CLEAR", False)
        self.enable_clear = False
        #
        self.dir_store = DataUtils.get_value(default, "STORE_PATH", None)
        self.dir_store = self.dir_store or os.path.join(os.path.expanduser('~'), "Data")
        self.dir_store = os.path.join(
            self.dir_store, str(self.category), str(self.domain), str(self.dtype)
        )
        DataUtils.ensure_dir(self.dir_store)
        self.logger.debug(f"STORE PATH: {self.dir_store}")
        #
        self.log_dirs = os.path.join(
            os.path.expanduser("~"),
            "Crawler",
            str(self.category),
            str(self.domain),
            "Deploy",
            "logs",
        )
        ##
        self.dbname = DataUtils.get_value(self.config["MYSQL"], "DBNAME", None)
        if self.dbname is None:
            self.dbname = f"im_{self.category}_{self.domain}"
        self.logger.debug(f"DBNAME: {self.dbname}")

        self.check_gather = 0
        self.gather_timeout = 1800
        self.statistic_date = None

    def dismiss(self):
        self.logger.warning("stopped")

    def working(self):
        self.logger.debug("DataGenService::working(): started.")
        started = 0
        while not self.stopping:
            try:
                time.sleep(0.5)
            except Exception as err:
                self.logger.exception(err)
                break

            if TimeUtils.timestamp() - started > self.retry_delay:
                try:
                    self._gen_recipe()
                finally:
                    started = TimeUtils.timestamp()

    def _gen_recipe(self):
        self.logger.debug("DataGenService::_gen_recipe(): started.")
        if self.dbname is None:
            self.stopping = True
            self.logger.error("load `DBNAME` failed, exit.")
            return

        start_hours = TimeUtils.strtime("%d")
        dbconf = self.config["MYSQL"]
        with MySQLHelper(
                host=dbconf["HOST"],
                port=int(dbconf["PORT"]),
                user=dbconf["USER"],
                passwd=dbconf["PASSWD"],
                dbname=self.dbname,
        ) as database:
            started, interval = 0, self.interval
            while not self.stopping:
                try:
                    time.sleep(0.5)
                except Exception as err:
                    self.logger.exception(err)
                    return
                if TimeUtils.strtime("%d") != start_hours:
                    self.logger.debug("New day, try to re-connect database.")
                    return

                if TimeUtils.timestamp() - started > interval:
                    try:
                        if DataUtils.get_free_disk() < self.alarm_disk_space_line:
                            self.logger.warning(
                                f"Local disk space is less than "
                                f"{DataUtils.format_size(self.alarm_disk_space_line)}, "
                                f"blocking recipe until has more disk space."
                            )
                            interval = 30 * 60
                        else:
                            interval = self.interval
                            self._gen_files(database)
                    except ReconnectError:
                        self.logger.error("database connection error.")
                        break
                    except Exception as err:
                        self.handle_exception(err)
                    finally:
                        started = TimeUtils.timestamp()

    def _gen_files(self, database: MySQLHelper):
        self.logger.debug("DataGenService::_gen_files(): invoked.")
        self.packet.clear()
        self.packet.update(
            {
                "ip":                 self.ip_addr,
                "category":           self.category,
                "domain":             self.domain,
                "scan_time":          TimeUtils.strtime(),
                "source":             self.module,
                TRANS_GC_RESULT:      [],
                SYNC_GC_SELF_ACCOUNT: [],
                SYNC_GC_TASK:         [],
                TRANS_GC_STATISTICS:  [],
            }
        )

        size = 0
        if (TimeUtils.timestamp() - self.check_gather) > self.gather_timeout:
            res = database.reset_result_gather_timeout(self.gather_timeout)
            if not res:
                raise ReconnectError(f"reset result gather timeout record")
            res = database.reset_task_gather_timeout(self.gather_timeout)
            if not res:
                raise ReconnectError(f"reset task gather timeout record")
            self.check_gather = TimeUtils.timestamp()

        result_rids, result_rows = self._prepared_result(database)
        if result_rows:
            self.logger.debug(f"prepare {len(result_rows)} result records.")
            self.packet[TRANS_GC_RESULT] = result_rows
            size += len(self.packet[TRANS_GC_RESULT])

        task_rids, tasks = self._prepared_tasks(database)
        if tasks:
            self.logger.debug(f"prepare {len(tasks)} exception task records.")
            self.packet[SYNC_GC_TASK] = tasks
            size += len(self.packet[SYNC_GC_TASK])

        if self.statistic_date != TimeUtils.yesterday_date():
            self.logger.debug("new day coming, start statistic recipe ...")
            self.statistic_date = TimeUtils.yesterday_date()
            records = self._prepare_statistics()
            if records:
                self.packet[TRANS_GC_STATISTICS_2] = records
                size += len(self.packet[TRANS_GC_STATISTICS_2])

        if size > 0:
            encrypted = self._encrypt_data(self.packet)
            if not encrypted:
                self.logger.error("encrypted prepared data failed.")
                return

            filepath = os.path.join(self.dir_store, f"{TimeUtils.timestamp(13)}.dat")
            self.logger.debug(f"store prepare encrypted data in {filepath}")
            with open(filepath, "wb") as fd:
                fd.write(encrypted)

        if self.enable_clear:
            if task_rids:
                res = database.delete_tasks(task_rids)
                self.logger.debug(f"Cleanup {len(task_rids)} task record: {res}")

            if result_rids:
                res = database.delete_results(result_rids)
                self.logger.debug(f"Cleanup {len(result_rids)} result record: {res}")

    def _encrypt_data(self, data):
        data_json = json.dumps(data)
        packed = {"id": DataUtils.get_md5(data_json), "data": data_json}
        packed = json.dumps(packed, ensure_ascii=False)
        bin_packed = packed.encode("UTF-8")

        ret = CryptoUtils.encrypt(bin_packed)
        if ret != 0:
            self.logger.error("Encrypt packed message fail.")
            return None

        compressed = DataUtils.zlib_compress(bin_packed)
        if not compressed:
            self.logger.error("Zlib compress fail.")
            return None
        self.logger.warning(
            f"Publish Package size: {DataUtils.format_size(len(compressed))}"
        )
        return compressed

    def _gen_packets(self):
        encrypted = self._encrypt_data(self.packet)
        if encrypted:
            filename = f"{TimeUtils.timestamp(13)}.dat"
            filepath = os.path.join(self.dir_store, filename)
            self.logger.debug(f"Generate {filepath}")
            with open(filepath, "wb") as fd:
                fd.write(encrypted)
            return True
        return False

    def _prepared_tasks(self, database: MySQLHelper):
        tasks = database.query_executed_tasks()
        if not tasks:
            return None, None

        rids = [t.pop("id") for t in tasks]
        for task in tasks:
            for k, v in task.items():
                if v is None or isinstance(v, int):
                    continue
                if isinstance(v, bytes):
                    task[k] = DataUtils.b64encode(v)
                else:
                    task[k] = str(v)

        res = database.update_task_gathered(rids, is_gathered=2)
        self.logger.debug(f"lock {len(tasks)} prepare-executed-task record: {res}")
        return rids, tasks

    def _prepared_result(self, database: MySQLHelper):
        results = database.query_results()
        if not results:
            return None, None

        rids = [r.pop("id") for r in results]
        for result in results:
            for k, v in result.items():
                if v is None or isinstance(v, int):
                    continue
                if isinstance(v, bytes):
                    result[k] = DataUtils.b64encode(v)
                else:
                    result[k] = str(v)
        res = database.update_result_gathered(rids, is_gathered=2)
        self.logger.debug(f"lock {len(results)} prepared-result records: {res}")
        return rids, results

    def _prepare_statistics(self):
        yesterday = TimeUtils.yesterday_date()
        log_file = f"{self.category}-{self.domain}-{yesterday}.log"
        self.logger.debug(f"start statistics {yesterday} logs, file: {log_file}")
        log_path = os.path.join(self.log_dirs, log_file)
        if not os.path.exists(log_path):
            self.logger.error(f"log file: {log_file} not exists.")
            return []

        uniques = {}
        with open(log_path, "r") as fd:
            for line in fd:
                if not re.search(r"batch_id(.*?) .*", line, re.M | re.I):
                    continue

                batch_id = re.search("batch_id\((.*?)\) .*(\d)", line, re.I).group(1)
                account = re.search("account\((.*?)\) .*(\d)", line, re.I).group(1)
                finish = eval(
                    (re.search("finish\((.*?)\) .*(\d)", line, re.I)).group(1)
                )
                success = eval((re.search("success\((.*?)\)", line, re.I)).group(1))

                uid = batch_id + account + yesterday
                if uid not in uniques.keys():
                    condition = {
                        "batch_id":    batch_id,
                        "category":    self.category,
                        "domain":      self.domain,
                        "date":        yesterday,
                        "server_ip":   self.ip_addr,
                        "account":     account,
                        "finish":      finish,
                        "success":     success,
                        "update_time": TimeUtils.strtime(),
                    }
                    uniques[uid] = condition
                else:
                    uniques[uid]["finish"] += finish
                    uniques[uid]["success"] += success

        return [v for v in uniques.values()]
