"""
Upload File to Special AMQP Server.

"""
import os
import time
import shutil

import pika

from common.base import IPlugins
from common.utils import DataUtils, TimeUtils, LoggerFactory
from common.keeper import ConnectionKeeperThread


class DataUploadService(IPlugins):
    VERSION = "20210120"

    def __init__(self, name: str, config: dict):
        super(DataUploadService, self).__init__(name, config)
        self.stopping = False
        self._start_timestamp = TimeUtils.timestamp()
        self.name = f"DataUploadService-{name}"
        self.pendings = []
        self.retry_delay = 60

    def handle_exception(self, exception):
        if self.logger:
            self.logger.exception(exception)

    def status(self):
        return ""

    def prepare(self):
        self.logger = LoggerFactory.initialize(self.name)
        self.local_ip = DataUtils.get_local_ip()
        self.local_ip_hash = DataUtils.get_md5(self.local_ip)

        default = DataUtils.get_value(self.config, "GLOBAL", {})
        self.allow_category = DataUtils.get_value(default, "CATEGORY", [])
        self.allow_domian = DataUtils.get_value(default, "DOMAIN", [])
        self.allow_dtype = DataUtils.get_value(default, "DATA_TYPE", [])

        self.enable_file_header = DataUtils.get_value(default, "FILE_HEADER", True)
        self.interval = DataUtils.get_value(default, "INTERVAL", 10)

        self.dir_scan = DataUtils.get_value(default, "DIR_PUBLISH", None)
        self.dir_scan = self.dir_scan or os.path.join(os.path.expanduser('~'), 'Data')
        self.dir_scan = os.path.normpath(self.dir_scan)
        DataUtils.ensure_dir(self.dir_scan)

        self.dir_err = DataUtils.get_value(default, "ERR_DIR_PUBLISH", None)
        if self.dir_err is None:
            self.dir_err = os.path.join(
                os.getcwd(), "Data", "Error", "Upload", self.name
            )
        self.dir_err = os.path.normpath(self.dir_err)
        DataUtils.ensure_dir(self.dir_err)

        #
        self.logger.debug(f"Version: {self.VERSION}")
        self.logger.debug(f"MachineID: {self.local_ip_hash}")
        self.logger.debug(f"Category: {self.allow_category}")
        self.logger.debug(f"Domain: {self.allow_domian}")
        self.logger.debug(f"Data Type: {self.allow_dtype}")
        self.logger.debug(f"Dir Upload: {self.dir_scan}")
        self.logger.debug(f"Generate Header: {self.enable_file_header}")
        self.logger.debug(f"Interval: {self.interval}")

    def dismiss(self):
        self.logger.info("stopped.")

    def working(self):
        self.logger.debug("DataUploadService::working(): started.")
        started = 0
        while not self.stopping:
            try:
                time.sleep(0.5)
            except Exception as err:
                self.logger.exception(err)
                return

            if TimeUtils.timestamp() - started > self.retry_delay:
                try:
                    self._upload_recipe()
                except Exception as err:
                    self.logger.exception(err)
                finally:
                    started = TimeUtils.timestamp()

    def _upload_recipe(self):
        rabbitmq = self.config["MQ"]
        parameters = pika.ConnectionParameters(
            host=rabbitmq["HOST"],
            port=int(rabbitmq["PORT"]),
            virtual_host=rabbitmq["VHOST"],
            credentials=pika.PlainCredentials(
                username=rabbitmq["USER"], password=rabbitmq["PASSWD"]
            ),
            heartbeat=3600,
        )
        _keep_connection_thread = None
        exchange = DataUtils.get_value(rabbitmq, "EXCHANGE", None)
        queue = DataUtils.get_value(rabbitmq, "QUEUE", None)
        route = DataUtils.get_value(rabbitmq, "ROUTE", None)
        if exchange is None or queue is None or route is None:
            self.stopping = True
            self.logger.error(f"Could not load AMQP `EXCHANGE` or `QUEUE` or `ROUTE`.")
            return

        self.logger.debug(f"EXCHANGE: {exchange}, QUEUE: {queue}, ROUTE: {route}")
        try:
            with pika.BlockingConnection(parameters) as connection:
                self.logger.debug(f"AMQP Connection: {id(connection)}")
                _keep_connection_thread = ConnectionKeeperThread(connection)
                _keep_connection_thread.start()

                channel = connection.channel()
                channel.exchange_declare(
                    exchange=exchange, exchange_type="topic", durable=True
                )
                channel.queue_declare(queue=queue, durable=True)
                channel.queue_bind(exchange=exchange, queue=queue, routing_key=route)
                channel.confirm_delivery()

                self._upload(connection, channel, exchange, route)

        except Exception as err:
            self.handle_exception(err)
            return
        finally:
            if _keep_connection_thread:
                _keep_connection_thread.shutdown()
                if _keep_connection_thread.state != "STOPPED":
                    _keep_connection_thread.join()

    def _upload(self, connection, channel, exchange, route):
        self.logger.debug("DatatUploadService::_upload(): invoked.")
        started = 0
        interval = self.interval
        while not self.stopping:
            try:
                time.sleep(0.5)
            except Exception as err:
                self.logger.exception(err)
                return

            if TimeUtils.timestamp() - started > interval:
                try:
                    self._prepare_message()
                    if len(self.pendings) > 0:
                        self._upload_files(connection, channel, exchange, route)
                finally:
                    started = TimeUtils.timestamp()

    def _upload_files(self, connection, channel, exchange, route):
        while len(self.pendings) > 0:
            path = self.pendings.pop(0)
            _, filename = os.path.split(path)
            self.logger.debug(f"start handle: {filename} ...")
            if os.path.getsize(path) == 0:
                self.logger.debug(f"This file is empty, delete it.")
                os.remove(path)
                continue

            cont = self._load_content(path)
            if cont is None:
                self.logger.error(f"load {filename} failed.")
                n_path = os.path.join(self.dir_err, filename)
                shutil.move(path, n_path)
                self.logger.error(f"move {filename} to error directory.")
                continue

            if self.enable_file_header:
                hash = DataUtils.get_md5(cont)
                header = self._generate_file_headers(path, hash)
                body = header + cont
            else:
                body = cont

            if not (channel and channel.is_open and connection and connection.is_open):
                raise RuntimeError("channel or connection are not available.")

            channel.basic_publish(
                exchange=exchange,
                routing_key=route,
                body=body,
                properties=pika.BasicProperties(delivery_mode=2),
            )
            os.remove(path)
            self.logger.debug(f"Upload {filename} success.")

    def _generate_file_headers(self, filepath, filehash):
        dirpath, filename = os.path.split(filepath)
        items = dirpath.split("/")
        category, domain, dtype = items[-3], items[-2], items[-1]
        header_suffix = "#".join(
            [category, domain, dtype, filename, self.local_ip_hash, filehash]
        )
        header_len = len(header_suffix)
        header = f"{header_len}#{header_suffix}"
        return header.encode("UTF-8")

    def _prepare_message(self, limit=10):
        self.logger.debug("DataUploadService::prepare_message(): invoked.")
        if len(self.pendings) > limit:
            return

        def _inner_gen_scans():
            dirs = []
            for category in self.allow_category:
                p = os.path.join(self.dir_scan, str(category))
                if not os.path.exists(p):
                    continue
                for domain in self.allow_domian:
                    p2 = os.path.join(p, str(domain))
                    if not os.path.exists(p2):
                        continue
                    for dtype in self.allow_dtype:
                        p3 = os.path.join(p2, str(dtype))
                        if not os.path.exists(p3):
                            continue
                        dirs.append(p3)
            return dirs

        def _inner_travel_dir(dirpath, size: int = 10):
            files = []
            for root, _, names in os.walk(dirpath):
                for name in names:
                    if name.endswith(".tmp"):
                        continue
                    if len(files) > size:
                        return files
                    abspath = os.path.join(root, name)
                    if abspath not in files:
                        files.append(abspath)
            return files

        for dirpath in _inner_gen_scans():
            files = _inner_travel_dir(dirpath, limit)
            if files:
                self.pendings.extend(files)

    def _load_content(self, path):
        try:
            with open(path, "rb") as fd:
                return fd.read()
        except Exception as err:
            self.logger.exception(err)
            return None
