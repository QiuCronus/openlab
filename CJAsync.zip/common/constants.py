TaskStatus = {
    0: "pending",
    1: "dealing",
    2: "success",
    3: "fail",
    4: "finish",
    5: "cancel",
}

SYNC_GC_TASK = "sync_gc_task"
SYNC_GC_SELF_ACCOUNT = "sync_gc_self_group"
SYNC_GC_MQ_RESULT = "sync_gc_mq_result"
SYNC_GC_GROUP = "sync_gc_group"

TRANS_GC_IM_ACCOUNT = "transfer_gc_im_account"
TRANS_GC_FRIEND = "transfer_gc_friend"
TRANS_GC_GROUP_MEMBER = "transfer_gc_group_member"
TRANS_GC_MSG = "transfer_gc_msg"
TRANS_GC_GROUP_RELATIONSHIP = "transfer_gc_group_relationship"
TRANS_GC_FILE_DOWNLOAD = "transfer_gc_file_download"
TRANS_GC_RESULT = "transfer_gc_result"
TRANS_GC_PROFILE = "transfer_gc_profile"
TRANS_GC_STATISTICS = "transfer_gc_statistics"
TRANS_GC_STATISTICS_2 = "transfer_gc_statistics_2"

CANCEL_GC_BATCH = "cancel_gc_batch"
CANCEL_GC_TASK = "cancel_gc_task"
DECLINE_GC_TASK = "decline_gc_task"
DECLINE_GC_SELF_ACCOUNT = "decline_gc_self_result"
DECLINE_GC_MQ_RESULT = "decline_gc_mq_result"
DELETE_GC_FRIEND = "delete_gc_friend"
DELETE_GC_GROUP = "delete_gc_group"
DELETE_GC_GROUP_MEMBER = "delete_gc_group_member"
DELETE_GC_MSG = "delete_gc_msg"
DELETE_GC_GROUP_RELATIONSHIP = "delete_gc_group_relationship"
DELETE_GC_FILE_DOWNLOAD = "delete_gc_file_download"
DELETE_GC_RESULT = "delete_gc_result"
DELETE_GC_PROFILE = "delete_gc_profile"
