import time
import pymysql
import pymysql.err
import pymysql.cursors

from common.utils import LoggerFactory

logger = LoggerFactory.initialize("MySQLHelper")


class MySQLHelper(object):
    def __init__(self, host, port, user, passwd, dbname):
        self.host = host
        self.port = port
        self.user = user
        self.passwd = passwd
        self.dbname = dbname
        self.connection = None

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.connection:
            self.connection.close()
        return False

    def connect(self):
        self.connection = pymysql.connect(
            host=self.host,
            port=self.port,
            user=self.user,
            password=self.passwd,
            database=self.dbname,
            charset="utf8mb4",
            connect_timeout=30,
            autocommit=True,
            cursorclass=pymysql.cursors.DictCursor,
        )

    def is_connected(self):
        try:
            self.connection.ping()
            return True
        except:
            return False

    def query_pending_task_size(self):
        try:
            with self.connection.cursor() as cursor:
                cursor.execute(
                    "select count(id) as count from im_task where task_status = 0;"
                )
                row = cursor.fetchone()
                if not row or "count" not in row:
                    raise RuntimeError("missing count field.")
                return row["count"]
        except Exception as err:
            logger.exception(err)
            return -1

    def reset_task_gather_timeout(self, deathline):
        try:
            with self.connection.cursor() as cursor:
                cursor.execute(
                    f"update im_task set is_gathered = 0, gather_time = {int(time.time())} where "
                    f"gather_time <= {deathline};"
                )
                return True
        except Exception as err:
            logger.exception(err)
            return False

    def reset_result_gather_timeout(self, deathline):
        try:
            with self.connection.cursor() as cursor:
                cursor.execute(
                    f"update im_result set is_gathered = 0, gather_time = {int(time.time())} where "
                    f"gather_time <= {deathline};"
                )
                return True
        except Exception as err:
            logger.exception(err)
            return False

    def reset_profile_gather_timeout(self, deathline):
        try:
            with self.connection.cursor() as cursor:
                cursor.execute(
                    f"update im_profile set is_gathered = 0, gather_time = {int(time.time())} where "
                    f"gather_time <= {deathline};"
                )
                return True
        except Exception as err:
            logger.exception(err)
            return False

    def count_available_tasks(self) -> int:
        try:
            with self.connection.cursor() as cursor:
                q = "SELECT count(*) as count FROM im_task WHERE task_status in (0, 1);"
                cursor.execute(q)
                ret = cursor.fetchone()
                if ret and "count" in ret:
                    return ret["count"]
                return -1
        except Exception as err:
            logger.exception(err)
            return -1

    def count_available_accounts(self) -> int:
        try:
            with self.connection.cursor() as cursor:
                q = "SELECT count(*) as count FROM im_self_account WHERE status = 0;"
                cursor.execute(q)
                ret = cursor.fetchone()
                return ret['count'] if ret and 'count' in ret else -1
        except Exception as err:
            logger.exception(err)
            return -1


    def query_executed_tasks(self, limit: int = 1000):
        try:
            with self.connection.cursor() as cursor:
                q = (
                    f"SELECT * FROM im_task WHERE "
                    f"is_gathered = 0 AND "
                    f"task_status >= 1 AND "
                    f"task_status < 99 "
                    f"ORDER BY id "
                    f"LIMIT {limit};"
                )
                cursor.execute(q)
                return cursor.fetchall()
        except Exception as err:
            logger.exception(err)
            return None

    def query_results(self, limit: int = 1000):
        try:
            with self.connection.cursor() as cursor:
                q = f"SELECT * FROM im_result WHERE is_gathered = 0 ORDER BY id LIMIT {limit};"
                cursor.execute(q)
                return cursor.fetchall()
        except Exception as err:
            logger.exception(err)
            return None

    def update_task_gathered(self, ids: list, is_gathered: int):
        try:
            with self.connection.cursor() as cursor:
                now = int(time.time())
                q = "UPDATE im_task SET is_gathered = %s, gather_time = %s WHERE id = %s;"
                condition = [(is_gathered, now, _id) for _id in ids]
                cursor.executemany(q, condition)
                return True
        except Exception as err:
            logger.exception(err)
            return False

    def update_result_gathered(self, ids: list, is_gathered: int):
        try:
            with self.connection.cursor() as cursor:
                now = int(time.time())
                q = "UPDATE im_result SET is_gathered = %s, gather_time = %s WHERE id = %s;"
                condition = [(is_gathered, now, _id) for _id in ids]
                cursor.executemany(q, condition)
                return True
        except Exception as err:
            logger.exception(err)
            return False

    def update_task_status(self):
        pass

    def delete_results(self, row_ids: list):
        try:
            with self.connection.cursor() as cursor:
                q = "delete from im_result where id = %s"
                condition = [(_id,) for _id in row_ids]
                cursor.executemany(q, condition)
                return True
        except Exception as err:
            logger.exception(err)
            return False

    def delete_tasks(self, row_ids: list):
        try:
            with self.connection.cursor() as cursor:
                q = "delete from im_task where id = %s"
                condition = [(_id,) for _id in row_ids]
                cursor.executemany(q, condition)
                return True
        except Exception as err:
            logger.exception(err)
            return False

    def add_tasks(self, records: list):
        try:
            with self.connection.cursor() as cursor:
                q = (
                    f"INSERT INTO im_task ("
                    f"`batch_id`, `task_id`, `target`, `category`, `domain`, `param1`, `param2`,"
                    f"`task_status`, `update_time`, `is_auto_join`, `task_priority`, `command`,"
                    f"`is_gathered`, `server_ip`, `is_deleted`, `use_count`, `is_dispatched`,"
                    f"`gather_time`) "
                    f"VALUES ("
                    f"%(batch_id)s,%(task_id)s,%(target)s,%(category)s,%(domain)s,%(param1)s,%(param2)s,%(task_status)s,"
                    f"%(update_time)s,%(is_auto_join)s,%(task_priority)s,%(command)s,%(is_gathered)s,%(server_ip)s,%(is_deleted)s,%(use_count)s,"
                    f"%(is_dispatched)s, %(gather_time)s);"
                )
                cursor.executemany(q, records)
                return True
        except Exception as err:
            logger.exception(err)
            return False

    def task_exists(self, batch_id: str, task_id: str, category: int, domain: int):
        try:
            with self.connection.cursor() as cursor:
                q = (
                    "SELECT count(id) as count "
                    "FROM im_task WHERE "
                    f"batch_id = '{batch_id}' and "
                    f"task_id = '{task_id}' and "
                    f"category = {category} and "
                    f"domain = {domain};"
                )
                result = cursor.execute(q)
                return True, result
        except Exception as err:
            logger.exception(err)
            return False, None

    def delete_task(self, batch_id: str, task_id: str, category: int, domain: int):
        try:
            with self.connection.cursor() as cursor:
                q = (
                    f"DELETE FROM im_task WHERE batch_id = '{batch_id}' and task_id = '{task_id}' and category = {category} and domain = {domain};"
                )
                cursor.execute(q)
                return True
        except Exception as err:
            logger.exception(err)
            return False