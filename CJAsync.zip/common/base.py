from threading import Thread
from abc import abstractmethod, ABCMeta


class IPlugins(Thread):
    def __init__(self, name: str, config: dict):
        super(IPlugins, self).__init__()
        self.stopping = False
        self.name = f"IPlugin-{name}"
        self.config = config
        self.logger = None
        self._start_timestamp = 0

    def shutdown(self):
        self.stopping = True
        if self.logger:
            self.logger.warning(f"{self.name} stopping ...")

    def run(self) -> None:
        try:
            self.prepare()
            self.working()
        except Exception as err:
            self.handle_exception(err)
        finally:
            self.dismiss()

    @abstractmethod
    def handle_exception(self, exception):
        raise NotImplementedError

    @abstractmethod
    def status(self):
        raise NotImplementedError

    @abstractmethod
    def prepare(self):
        raise NotImplementedError

    @abstractmethod
    def dismiss(self):
        raise NotImplementedError

    @abstractmethod
    def working(self):
        raise NotImplementedError
