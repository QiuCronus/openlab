from threading import Lock
import os
import sqlite3


def dict_factory(cursor, row):
    return {col[0]: row[idx] for idx, col in enumerate(cursor.description)}


class SQLiteHelper:
    _instance_lock = Lock()

    DB_FILE = os.path.join(os.getcwd(), "plugin.db")

    @classmethod
    def instance(cls):
        if not hasattr(cls, "_instance"):
            with SQLiteHelper._instance_lock:
                if not hasattr(cls, "_instance"):
                    SQLiteHelper._instance = SQLiteHelper()
                    SQLiteHelper._instance.__init()
                    SQLiteHelper._instance.__reset()
        return SQLiteHelper._instance

    def __init(self):
        self.connection = sqlite3.connect(self.DB_FILE, check_same_thread=False)
        self.connection.row_factory = dict_factory
        init_sql = (
            "CREATE TABLE IF NOT EXISTS `plugin`("
            "`uid` VARCHAR(32) NOT NULL, "
            "`name` VARCHAR(32) NOT NULL, "
            "`status` INT(2) DEFAULT 0,"
            "`config` VARCHAR(128) NOT NULL, "
            " UNIQUE(uid));"
        )
        self.connection.execute(init_sql)

    def __reset(self):
        q = "UPDATE `plugin` SET `status` = 1 WHERE `status` = 2;"
        try:
            self.connection.execute(q)
            self.connection.commit()
            return True
        except:
            self.connection.rollback()
            return False

    def add(self, uid, name, config):
        if self._exists(uid):
            return False
        q = (
            f"INSERT INTO `plugin` ("
            f"`uid`, `name`, `status`, `config`) VALUES ("
            f"'{uid}', '{name}', 1, '{config}');"
        )
        try:
            self.connection.execute(q)
            self.connection.commit()
            return True
        except:
            return False

    def delete(self, uid):
        q = f"DELETE FROM `plugin` WHERE `uid` = '{uid}';"
        try:
            self.connection.execute(q)
            self.connection.commit()
            return True
        except:
            self.connection.rollback()
            return False

    def query(self):
        q = "SELECT `uid`, `name`, `config` FROM `plugin` WHERE `status` > 0;"
        try:
            return [row for row in self.connection.execute(q)]
        except:
            return []

    def query_status(self, uid):
        q = f"SELECT `status` FROM `plugin` WHERE `uid` = '{uid}';"
        try:
            cursor = self.connection.execute(q)
            r = cursor.fetchone()
            if not r:
                return None
            return int(r["status"])
        except:
            return None

    def _update_status(self, uid, status):
        if not self._exists(uid):
            return False

        q = f"UPDATE `plugin` SET `status` = {status} WHERE `uid` = '{uid}';"
        try:
            self.connection.execute(q)
            self.connection.commit()
            return True
        except:
            self.connection.rollback()
            return False

    def plugin_disabled(self, uid):
        return self._update_status(uid, 0)

    def plugin_started(self, uid):
        return self._update_status(uid, 2)

    def plugin_stopped(self, uid):
        return self._update_status(uid, 1)

    def _exists(self, uid):
        q = f"SELECT `name` FROM `plugin` WHERE `uid` = '{uid}';"
        try:
            cursor = self.connection.execute(q)
            r = cursor.fetchone()
            return True if r and "name" in r else False
        except:
            return False
