import copy

from flask import Flask, request, jsonify

from core.manager import Manager

app = Flask("Transfer", instance_relative_config=True)
Instance = Manager.instance()


def normalize_args(data):
    data = dict(data)
    return {
        key: values[0] if isinstance(values, list) else values
        for key, values in data.items()
    }


@app.route("/upgrade", methods=["GET"])
def update_plugin():
    args = normalize_args(copy.copy(request.args))
    uid = args.get("uid", None)
    name = args.get("name", None)
    config = args.get("config", None)
    if uid and name and config:
        uid = Instance.update_plugin(uid, name, config)
        return jsonify({"code": 200, "msg": uid})

    return jsonify({"code": 200, "msg": "parameter error"})


@app.route("/start", methods=["GET"])
def start_plugin():
    args = normalize_args(copy.copy(request.args))
    name = args.get("name", None)
    config = args.get("config", None)

    if name and config:
        uid = Instance.start_plugin(name, config)
        return jsonify({"code": 200, "msg": uid})

    return jsonify({"code": 200, "msg": "parameter error"})


@app.route("/stop", methods=["GET"])
def stop_plugin():
    args = normalize_args(copy.copy(request.args))
    uid = args.get("uid", None)
    if uid:
        if Instance.stop_plugin(uid):
            return jsonify({"code": 200, "msg": "stopped"})
        else:
            return jsonify({"code": 400, "msg": "stop error."})
    return jsonify({"code": 400, "msg": "parameter error"})


@app.route("/check", methods=["GET"])
def check_plugins():
    infos = Instance.check_plugins()
    return jsonify({"code": 200, "msg": infos})


@app.route("/stop_all", methods=["GET"])
def stop_all_plugins():
    Instance.shutdown()
    return jsonify({"code": 200, "msg": ""})


def start_app():
    Instance.init()
    try:
        app.run(host="127.0.0.1", port=9902)
    finally:
        Instance.shutdown()


if __name__ == "__main__":
    start_app()
